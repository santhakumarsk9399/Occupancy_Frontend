import React from "react";
import PropTypes from "prop-types";
import DateFilter from "./DateFilter";
import './LogTable.css';
import DataTable from "react-data-table-component";
import Loader from "../CommonComponents/Loader";



  const conditionalRowStyles = [
    // {
    //   when: (row) => row.id === selectedRowId,
    //   style: {
    //     backgroundColor: "#f6f7fc",
    //   },
    // },
  ];
  const columns = [
    {
      name: "SL",
      selector: (row) => row.Sl,
        width: '70px', // match Thresholds table narrow SL column
    },
    {
      name: "DATE AND TIME",
  selector: (row) => row.fullDate || row.date,
    },
    {
      name: "USER NAME",
  selector: (row) => row.userName,
    },
    {
      name: "DESCRIPTION",
  selector: (row) => row.description,
    },
    {
      name: "EVENT",
  selector: (row) => row.event,
    },
  ];

const LogTable = ({
  logs,
  selectedDate,
  dateFilterProps,
  userFilterProps,
  eventFilterProps,
  isLoading = false,
}) => {
  // DataGrid requires a unique id for each row
  // Normalize incoming API keys (e.g., SL, Date, UserName, Description, Event) to the
  // keys used by the table columns (Sl, date, userName, description, event)
  // Some API responses wrap the log objects in an extra array level: logs: [[{...}, {...}]]
  // Flatten one (or two) nesting levels defensively.
  const flatLogs = Array.isArray(logs)
    ? (Array.isArray(logs[0]) ? logs.flat(2) : logs)
    : [];

  const rows = flatLogs.map((log, idx) => ({
    id: idx,
    // Support multiple possible casings / variants defensively
    Sl: log.Sl ?? log.SL ?? log.sl ?? (idx + 1),
    date: log.date ?? log.Date ?? "",
    fullDate: log.fullDate ?? log.FullDate ?? log.Date ?? log.date ?? "",
    userName: log.userName ?? log.UserName ?? "",
    description: log.description ?? log.Description ?? "",
    event: log.event ?? log.Event ?? "",
  }));

  const UserFilterComp = userFilterProps?.component;
  const EventFilterComp = eventFilterProps?.component;
  const customStyles = {
    headCells: {
      style: {
        backgroundColor: "#ffffff",
        color: "black",
        fontWeight: "300",
        fontSize: "14px",
        textTransform: "uppercase",
        borderBottom: "2px solid #ddd",
        fontFamily: "Inter, sans-serif",
      },
    },
    cells: {
      style: {
        fontSize: "16px",
        fontWeight: "400",
        padding: "10px 15px",
        fontFamily: "Inter, sans-serif",
      },
    },
    rows: {
      style: {
        minHeight: "48px", // row height
        "&:hover": {
          backgroundColor: "#f0f9ff", // hover background
          cursor: "pointer",
          fontFamily: "Inter, sans-serif",
        },
      },
    },
    pagination: {
      style: {
        borderTop: "1px solid #ddd",
        padding: "10px",
        fontFamily: "Inter, sans-serif",
      },
    },
  };

  return (
    <div className="log-table-wrapper">
      {isLoading ? (
        <Loader />
      ) : (
        <>
          {logs.length > 0 && (
            <div className="table-header">
              <div className="table-controls">
                {UserFilterComp && <UserFilterComp {...userFilterProps} />}
                {EventFilterComp && <EventFilterComp {...eventFilterProps} />}
                {dateFilterProps && <DateFilter {...dateFilterProps} />}
              </div>
            </div>
          )}

          <div style={{ width: "100%" }}>
            <div style={{ maxHeight: "650px", overflowY: "scroll" }}>
              <DataTable
                columns={columns}
                data={rows}
                highlightOnHover
                pointerOnHover
                selectableRowsHighlight
                conditionalRowStyles={conditionalRowStyles}
                pagination
                paginationPerPage={10}
                paginationRowsPerPageOptions={[10, 20, 30]}
                responsive
                customStyles={customStyles}
              />
            </div>
          </div>
        </>
      )}
    </div>
  );
};

LogTable.propTypes = {
  logs: PropTypes.arrayOf(
    PropTypes.shape({
      date: PropTypes.string.isRequired,
      userName: PropTypes.string.isRequired,
      description: PropTypes.string.isRequired,
      event: PropTypes.string.isRequired,
    })
  ).isRequired,
  selectedDate: PropTypes.string.isRequired,
  dateFilterProps: PropTypes.object,
  userFilterProps: PropTypes.shape({
    component: PropTypes.elementType.isRequired,
  }),
  eventFilterProps: PropTypes.shape({
    component: PropTypes.elementType.isRequired,
  }),
  isLoading: PropTypes.bool,
};

export default LogTable;