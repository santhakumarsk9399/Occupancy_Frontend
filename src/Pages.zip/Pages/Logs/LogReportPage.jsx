import React, { useState, useEffect, useRef } from "react";
import { toast } from "react-toastify";
import axios from "axios";
import SearchBar from "../Logs/SearchBar";
import DateFilter from "../Logs/DateFilter";
import LogTable from "../Logs/LogTable";
import '../Logs/common.css';
import { showError } from "../CommonComponents/Toaster";

const API_URL = import.meta.env.VITE_API_URL; // API main url

function getTodayString() {
  const today = new Date();
  return today.toISOString().slice(0, 10);
}

const Footer = 'Copyright © 2025 All Rights Reserved by';

function LogReportPage() {
  const [search, setSearch] = useState("");
  const [date, setDate] = useState(getTodayString());
  const [pendingDate, setPendingDate] = useState(getTodayString());
  const [selectedUser, setSelectedUser] = useState([]);
  const [pendingUser, setPendingUser] = useState([]);
  const [selectedEvent, setSelectedEvent] = useState([]);
  const [pendingEvent, setPendingEvent] = useState([]);
  const [logs, setLogs] = useState([]);
  const [uniqueUsers, setUniqueUsers] = useState([]);
  const [uniqueEvents, setUniqueEvents] = useState([]);
  const [loading, setLoading] = useState(true);
  const [token, setToken] = useState("");
  // Track when initial users/events fetched to avoid early empty warnings
  const initialDataLoadedRef = useRef(false);


  const tokenVal = sessionStorage.getItem("token"); // token
  const vid = sessionStorage.getItem("vid"); // vendor id
  const username = sessionStorage.getItem("username"); // username

  useEffect(() => {
    const fetchAll = async () => {
      setLoading(true);
      try {
        const payload = {
          vid,
          username: username,
        };
        let usersEventsRes = await axios.post(
          `${API_URL}/settings/logs/usersEvents`,
          payload,
          {
            headers: {
              Authorization: `Bearer ${tokenVal}`,
            },
          }
        );
        const users = (usersEventsRes.data.users || []).flat().map(u => u.UserName);
        const events = (usersEventsRes.data.events || []).flat().map(e => e.Events);

        setUniqueUsers(users);
        setUniqueEvents(events);

        setPendingUser(users);
        setPendingEvent(events);
        setSelectedUser(users);
        setSelectedEvent(events);

        // Mark initial data loaded once we have user/event lists
        initialDataLoadedRef.current = true;

        await fetchLogs({
          username: users.join(","),
          events: events.join(","),
          fromDate: getTodayString(),
          toDate: getTodayString()
        }, token);

      } catch (err) {
        setLogs([]);
        setUniqueUsers([]);
        setUniqueEvents([]);
        setToken("");
        console.error("Failed to fetch data:", err);
      } finally {
        setLoading(false);
      }
    };
    fetchAll();
    // eslint-disable-next-line
  }, []);

  // (Removed live validation to ensure toast appears only on Apply click)


  const fetchLogs = async (params, overrideToken) => {
    setLoading(true);
    try {
      //  console.log(params.UserName?.map(option => option.UserName).join(", ")||"",);
      console.log(params);

      // const payload = {
      //   vid,

      //   username : params.username,
      //   events: params.events,
      //   fromDate: params.fromDate,
      //   toDate: params.toDate,
      //   startTime: "0",
      //   endTime: "23"
      // };

      const payload = {
        vid,
        username: Array.isArray(params.username)
          ? params.username.map(u =>
            typeof u === "object"
              ? u.UserName || u.value || ""
              : u
          ).join(",")
          : params.username || "",
        events: Array.isArray(params.events)
          ? params.events.map(e =>
            typeof e === "object"
              ? e.Events || e.value || ""
              : e
          ).join(",")
          : params.events || "",
        fromDate: params.fromDate,
        toDate: params.toDate,
        startTime: "0",
        endTime: "23"
      };


      let res = await axios.post(
        `${API_URL}/settings/logs/getAuditLogs`,
        payload,
        {
          headers: {
            Authorization: `Bearer ${tokenVal}`,
          },
        }
      );

      // Helper to normalize various date formats to 'YYYY-MM-DD'
      const normalizeDate = (log) => {
        if (log.CtDateTime) {
          return log.CtDateTime.split('T')[0];
        }
        if (log.Date) {
          const firstPart = log.Date.split(' ')[0];
          const parts = firstPart.split('-'); // DD-MM-YYYY
          if (parts.length === 3) {
            const [dd, mm, yyyy] = parts;
            if (yyyy && mm && dd) return `${yyyy}-${mm}-${dd}`;
          }
        }
        return '';
      };

      const buildFullDate = (log) => {
        if (log.Date) return log.Date; // already in desired full format
        if (log.CtDateTime) {
          // Convert ISO to DD-MM-YYYY HH:mm:ss.mmm
          const [ymd, timePart] = log.CtDateTime.split('T');
          if (ymd && timePart) {
            const [yyyy, mm, dd] = ymd.split('-');
            return `${dd}-${mm}-${yyyy} ${timePart}`;
          }
        }
        return '';
      };

      const rawLogs = (res.data.logs || []).flat();
      const apiLogs = rawLogs.map((log, idx) => ({
        Sl: log.SL || log.Sl || log.sl || (idx + 1),
        date: normalizeDate(log), // normalized date for filtering (YYYY-MM-DD)
        fullDate: buildFullDate(log), // full original formatted date-time
        userName: log.UserName || log.username || '',
        description: log.Description || log.description || '',
        event: log.Event || log.event || ''
      }));
      setLogs(apiLogs);
    } catch (err) {
      setLogs([]);
      console.error("Failed to fetch logs:", err);
    } finally {
      setLoading(false);
    }
  };

  const handleSearch = (e) => setSearch(e.target.value);

  const handleDateChange = (e) => {
    setPendingDate(e.target.value);
  };

  const handleClear = () => {
    const today = getTodayString();
    setPendingDate(today);
    setPendingUser(uniqueUsers);
    setPendingEvent(uniqueEvents);
    setSearch("");
    setDate(today);
    setSelectedUser(uniqueUsers);
    setSelectedEvent(uniqueEvents);

    fetchLogs({
      username: uniqueUsers.join(","),
      events: uniqueEvents.join(","),
      fromDate: today,
      toDate: today
    });
  };

  const handleApply = () => {
    // Validate selections with a single guard + early return
    if (!pendingUser.length || !pendingEvent.length) {
      if (!pendingUser.length && !pendingEvent.length) {
        console.error("Apply failed: Please select at least one user and one event.");
        showError("Please select at least one user and one event.");
      } else if (!pendingUser.length) {
        console.error("Apply failed: Please select at least one user.");
        showError("Please select at least one user.");
      } else {
        console.error("Apply failed: Please select at least one event.");
        showError("Please select at least one event.");
      }
      return; // prevent fetch when invalid
    }

    setDate(pendingDate);
    setSelectedUser([...pendingUser]);
    setSelectedEvent([...pendingEvent]);
    setSearch("");

    fetchLogs({
      username: pendingUser.join(","),
      events: pendingEvent.join(","),
      fromDate: pendingDate,
      toDate: pendingDate
    });
  };

  const handleUserChange = (values) => {
    setPendingUser(Array.isArray(values) ? values : []);
  };

  const handleEventChange = (values) => {
    setPendingEvent(Array.isArray(values) ? values : []);
  };

  const shouldDisableClear = () => {
    return pendingDate === getTodayString() &&
      pendingUser.length === uniqueUsers.length &&
      pendingEvent.length === uniqueEvents.length &&
      search === "";
  };

  const userOptions = uniqueUsers.map(u => ({ value: u, label: u }));
  const eventOptions = uniqueEvents.map(e => ({ value: e, label: e }));

  const filteredLogs = logs.filter((log) => {
    const searchVal = search.toLowerCase();
    const matchesSearch = !searchVal ||
      log.description?.toLowerCase().includes(searchVal) ||
      log.userName?.toLowerCase().includes(searchVal) ||
      String(log.Sl || log.SL || '').includes(searchVal);
    const matchesDate = !date || log.date === date; // both normalized to YYYY-MM-DD
    const matchesUser = !selectedUser || selectedUser.length === 0 || selectedUser.includes(log.userName);
    const matchesEvent = !selectedEvent || selectedEvent.length === 0 || selectedEvent.includes(log.event);
    return matchesSearch && matchesDate && matchesUser && matchesEvent;
  });

  // Let LogTable render its own loader using isLoading

  return (
    <div className="Logs_container">
      <div><p><span className="top-tab-head">Audit Logs</span></p></div>
      <div className="bg">
        {/* <h1 className="logs-header">Logs</h1> */}
        {/* <div className="header-gap    "></div> */}
      </div>
      <div className="logs-container">
        <div className="card mt-0 log-card">
          <div className="controls mb-0">
            <div className="filter-row">
              <SearchBar
                value={search}
                onChange={handleSearch}
                users={userOptions}
                events={eventOptions}
                selectedUser={pendingUser}
                selectedEvent={pendingEvent}
                onUserChange={handleUserChange}
                onEventChange={handleEventChange}
              />


              <DateFilter
                value={pendingDate}
                onChange={handleDateChange}
                onClear={handleClear}
                onApply={handleApply}
                disableClear={shouldDisableClear()}
              />
            </div>
          </div>
          <LogTable logs={filteredLogs} selectedDate={date} isLoading={loading} />
        </div>

        {/* Toast notifications are handled globally by ToasterContainer in App.jsx */}
      </div>
    </div>
  );
}

export default LogReportPage;