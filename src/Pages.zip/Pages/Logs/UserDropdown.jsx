import React, { useEffect, useState } from "react";
import axios from "axios";
import MultiSelectDropdown from "../CommonComponents/MultiSelectDropDown";
import "../../Components/Styles/Multiselectdropdown.css";

// A small dropdown that fetches users and exposes a single-selection API,
// but uses the shared MultiSelect UI so styles match the rest of the app.
const UserDropdown = ({ value = "", onChange = () => {} }) => {
  const [token, setToken] = useState("");
  const [users, setUsers] = useState([]);

  useEffect(() => {
    const loginAndFetchUsers = async () => {
      try {
        const loginResponse = await axios.post(
          "http://localhost:3000/auth/login",
          { username: "Occupancy", password: "Yuvi" },
          { headers: { "Content-Type": "application/json" } }
        );

        const receivedToken = loginResponse.data.token?.token;
        if (!receivedToken) return;
        setToken(receivedToken);

        const userResponse = await axios.post(
          "http://localhost:3000/settings/logs/usersEvents",
          { vid: 4, username: "Occupancy" },
          { headers: { Authorization: `Bearer ${receivedToken}`, "Content-Type": "application/json" } }
        );

        if (userResponse.data.success && Array.isArray(userResponse.data.users)) {
          setUsers(userResponse.data.users.map((u) => ({ label: u.username, value: u.username })));
        } else if (userResponse.data.success && userResponse.data.user) {
          setUsers([{ label: userResponse.data.user.username, value: userResponse.data.user.username }]);
        }
      } catch (error) {
        console.error("Error fetching users:", error);
      }
    };

    loginAndFetchUsers();
  }, []);

  // Represent current value as an array of selected option objects (MultiSelect expects array)
  const selected = users.filter((u) => u.value === value);

  const handleChange = (newArray) => {
    // MultiSelect returns array of option objects; choose first or empty string
    const next = Array.isArray(newArray) && newArray.length > 0 ? newArray[0].value : "";
    onChange(next);
  };

  return (
    <div style={{ margin: "8px 0", minWidth: 200 }}>
      <label style={{ display: 'block', marginBottom: 6 }}>Select User</label>
      <MultiSelectDropdown
        options={users}
        value={selected}
        onChange={handleChange}
        placeholder="All Users"
      />
    </div>
  );
};

export default UserDropdown;