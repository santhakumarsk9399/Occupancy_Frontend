import React from "react";
import PropTypes from "prop-types";
import MultiSelectDropdown from "../CommonComponents/MultiSelectDropDown";
import "../../Components/Styles/Multiselectdropdown.css";

// Thin wrapper to adapt the common MultiSelectDropdown API to the Logs folder usage
const LabeledDropdown = ({ label, value, onChange, options = [], placeholder = "Select" }) => {
  // Normalize incoming options (strings or objects) to { label, value }
  const opts = options.map((opt) =>
    typeof opt === "string"
      ? { label: opt, value: opt }
      : { label: opt.label ?? String(opt.value), value: opt.value ?? opt.label }
  );

  // Convert value (array of primitive values) into array of option objects expected by MultiSelectDropdown
  const selected = opts.filter((o) => Array.isArray(value) && value.includes(o.value));

  const handleChange = (newSelectedArray) => {
    // Map back to array of primitive values for the parent
    const vals = Array.isArray(newSelectedArray) ? newSelectedArray.map((o) => o.value) : [];
    onChange(vals);
  };

  return (
    <div className="filter-group">
      <label className="filter-label">{label}</label>
      <MultiSelectDropdown
        options={opts}
        value={selected}
        onChange={handleChange}
        placeholder={placeholder}
      />
    </div>
  );
};

LabeledDropdown.propTypes = {
  label: PropTypes.string.isRequired,
  value: PropTypes.array.isRequired,
  onChange: PropTypes.func.isRequired,
  options: PropTypes.array.isRequired,
  placeholder: PropTypes.string,
};

export default LabeledDropdown;

