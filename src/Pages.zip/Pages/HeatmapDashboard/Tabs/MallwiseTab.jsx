import React from 'react'

const MallwiseTab = () => {
  return (
    <div>MallwiseTab</div>
  )
}

export default MallwiseTab