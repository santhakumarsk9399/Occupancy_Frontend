import React, { useState } from "react";
// import TabBar from "./components/TabBar";
// import FilterButton from "./components/FilterButton";
// import FilterDrawer from "./components/FilterDrawer";
import LiveTab from "./Tabs/LiveTab";
import MallWiseTab from "./Tabs/MallwiseTab";
import ZoneWiseTab from "./Tabs/ZoneWiseTab";
import MapWiseTab from "./Tabs/MapWiseTab";
// import "./HeatmapDashboard.css";

const TABS = [
  { key: "live",     label: "Live" },
  { key: "mallwise", label: "Mall-wise" },
  { key: "zonewise", label: "Zone-wise" },
  { key: "mapwise",  label: "Map-wise" },
];

function HeatmapDashboard() {
  const [activeTab, setActiveTab]       = useState("live");
  const [filterOpen, setFilterOpen]     = useState(false);
  const [filters, setFilters]           = useState({
    mall:      "Nexus Mall - BLR",
    floor:     "Ground Floor",
    zone:      "",
    dateRange: "live",
    customDate: "",
  });

  const tabTitles = {
    live:     "Heat Map - Overview",
    mallwise: "Heat Map - Mall Wise",
    zonewise: "Heat Map - Zone Wise",
    mapwise:  "Heat Map - Map Wise",
  };

  const renderTab = () => {
    switch (activeTab) {
      case "live":     return <LiveTab filters={filters} />;
      case "mallwise": return <MallWiseTab filters={filters} setFilters={setFilters} />;
      case "zonewise": return <ZoneWiseTab filters={filters} setFilters={setFilters} />;
      case "mapwise":  return <MapWiseTab filters={filters} setFilters={setFilters} />;
      default:         return null;
    }
  };

  return (
    <div className="hm-root">
      {/* Page header */}
      <div className="hm-page-header">
        <h1 className="hm-page-title">{tabTitles[activeTab]}</h1>
        <FilterButton onClick={() => setFilterOpen(true)} />
      </div>

      {/* Tab bar */}
      <TabBar tabs={TABS} active={activeTab} onChange={setActiveTab} />

      {/* Tab content */}
      <div className="hm-content">
        {renderTab()}
      </div>

      {/* Filter drawer */}
      {/* <FilterDrawer
        open={filterOpen}
        activeTab={activeTab}
        filters={filters}
        onChange={setFilters}
        onClose={() => setFilterOpen(false)}
      /> */}
    </div>
  );
}

export default HeatmapDashboard;
