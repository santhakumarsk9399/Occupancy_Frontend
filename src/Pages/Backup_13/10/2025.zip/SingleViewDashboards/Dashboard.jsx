// import React, { useCallback, useEffect, useMemo, useState } from "react";
// import { fetchZones, fetchDashboard } from "./api";
// import {
//   XAxis,
//   YAxis,
//   Tooltip,
//   ResponsiveContainer,
//   ReferenceLine,
//   CartesianGrid,
//   Area,
//   Line,
//   AreaChart,
// } from "recharts";
// import "./Dashboard.css";

// // Assets
// import OccupancyIcon from "../../components/Assets/dashboard/sv_occupancy.svg";
// import CapacityIcon from "../../components/Assets/dashboard/sv_capcity.svg";
// import PercentageIcon from "../../components/Assets/dashboard/sv_percentage.svg";
// import SafeIcon from "../../components/Assets/dashboard/sv_safetoenter.svg";
// import AlmostFullIcon from "../../components/Assets/dashboard/sv_allmostfull.svg";
// import FullIcon from "../../components/Assets/dashboard/sv_full.svg";
// import EmptyIcon from "../../components/Assets/dashboard/sv_empty.svg";
// import RemainingCapacityIcon from "../../components/Assets/dashboard/sv_remainingcapacity.svg";
// import PeakOccIcon from "../../components/Assets/dashboard/sv_peakoccupancy.svg";
// import PeakHourIcon from "../../components/Assets/dashboard/sv_peakhour.svg";
// import TotalInIcon from "../../components/Assets/dashboard/total-in.svg";
// import TotalOutIcon from "../../components/Assets/dashboard/total-out.svg";
// import Footer from "../CommonComponents/Footer";
// import SingleSelectDropdown from "../CommonComponents/SingleSelectDropdown"; // ✅ Import dropdown

// export default function Dashboard() {
//   const [token, setToken] = useState(null);
//   const [zones, setZones] = useState([]);
//   const [zoneIndex, setZoneIndex] = useState(0);
//   const [data, setData] = useState(null);
//   const [loading, setLoading] = useState(true);
//   const [refreshing, setRefreshing] = useState(false);
//   const [error, setError] = useState(null);

//   const activeZone = zones[zoneIndex];

//   // 🔑 Load token + zones on mount
//   useEffect(() => {
//     let mounted = true;
//     (async () => {
//       try {
//         const userData = JSON.parse(sessionStorage.getItem("userData"));
//         if (!userData?.token) {
//           throw new Error("Missing session token, please log in again");
//         }

//         if (!mounted) return;
//         setToken(userData.token);

//         const z = await fetchZones(
//           userData.token,
//           userData.user.vid,
//           userData.user.username
//         );
//         if (!mounted) return;
//         setZones(z);
//       } catch (e) {
//         if (mounted) setError(e.message);
//       }
//     })();
//     return () => {
//       mounted = false;
//     };
//   }, []);

//   // 📊 Load dashboard data when zone changes
//   const loadData = useCallback(
//     async (zone, isRefresh = false) => {
//       if (!token || !zone) return;
//       if (isRefresh) setRefreshing(true);
//       else setLoading(true);

//       setError(null);
//       try {
//         const d = await fetchDashboard(token, zone);
//         setData(d);
//       } catch (e) {
//         setError(e.message);
//       } finally {
//         if (isRefresh) setRefreshing(false);
//         else setLoading(false);
//       }
//     },
//     [token]
//   );

//   useEffect(() => {
//     if (token && activeZone) {
//       loadData(activeZone); // only when zone changes
//     }
//   }, [token, activeZone, loadData]);

//   // ⏱️ Rotate zones every 15s
//   useEffect(() => {
//     if (!zones.length) return;

//     const id = setInterval(() => {
//       setZoneIndex((prev) => {
//         const next = (prev + 1) % zones.length;
//         return next;
//       });
//     }, 15000);

//     return () => clearInterval(id);
//   }, [zones.length]);

//   // 🔄 Refresh zones list every 15s (auto-update dropdown)
//   useEffect(() => {
//     if (!token) return;

//     let mounted = true;
//     const userData = JSON.parse(sessionStorage.getItem("userData"));
//     if (!userData) return;

//     const fetchAndSetZones = async () => {
//       try {
//         const z = await fetchZones(
//           token,
//           userData.user.vid,
//           userData.user.username
//         );

//         if (mounted && Array.isArray(z)) {
//           setZones((prevZones) => {
//             if (JSON.stringify(prevZones) !== JSON.stringify(z)) {
//               return z;
//             }
//             return prevZones;
//           });

//           setZoneIndex((prevIndex) => {
//             if (z.length === 0) return 0;
//             return Math.min(prevIndex, z.length - 1);
//           });
//         }
//       } catch (e) {
//         console.error("Failed to refresh zones", e.message);
//       }
//     };

//     fetchAndSetZones();
//     const id = setInterval(fetchAndSetZones, 15000);

//     return () => {
//       mounted = false;
//       clearInterval(id);
//     };
//   }, [token]);

//   // ✅ Create dropdown options
//   const zoneOptions = useMemo(
//     () => zones.map((z, i) => ({ value: i, label: z })),
//     [zones]
//   );

//   const hourly = useMemo(() => data?.hourlyData || [], [data]);
//   const status = data?.peakStats?.Status || "";
//   const statusLower = status;
//   let badgeCls = "badge-safe";
//   if (statusLower.includes("Almost Full")) {
//     badgeCls = "badge-almost";
//   } else if (statusLower.includes("Full")) {
//     badgeCls = "badge-full";
//   } else if (statusLower.includes("Empty")) {
//     badgeCls = "badge-empty";
//   } else if (statusLower.includes("Safe to Enter")) {
//     badgeCls = "badge-safe";
//   }

//   return (
//     <div className="dashboard-wrapper">
//       <div className="single_dashboard-header">
//         <div className="dashboard-projectTitle">
//           <h3 className="mb-0">
//             Occupancy<span>2.0</span>
//           </h3>
//         </div>

//         <div className="dashboard-title">
//           <h2 className="mb-0">{activeZone || "--"}</h2>
//         </div>

//         <div className="zone-selector">
//           <label>Zone</label>
//           <SingleSelectDropdown
//             options={zoneOptions}
//             value={zoneOptions.find((o) => o.value === zoneIndex) || null}
//             onChange={(option) => setZoneIndex(option ? option.value : 0)}
//             placeholder="Select Zone"
//             className="singlezoneDropdown"
//           />
//         </div>
//       </div>

//       {error && <div className="error-banner">{error}</div>}

//       {/* Stats Grid */}
//       <div className="dash3-stat-grid">
//         <StatCard icon={OccupancyIcon} label="Live Occupancy">
//           <AnimatedNumber value={data?.liveStats?.LiveOccupancy} />
//         </StatCard>
//         <StatCard icon={CapacityIcon} label="Max Capacity">
//           <AnimatedNumber value={data?.capacityStats?.Maxcapacity} />
//         </StatCard>
//         <StatCard icon={PercentageIcon} label="Percentage ">
//           <AnimatedNumber value={data?.liveStats?.Percentage} suffix="%" />
//         </StatCard>

//         <div className={`dash3-status-badge ${badgeCls}`}>
//           <img
//             src={
//               statusLower.includes("Safe to Enter")
//                 ? SafeIcon
//                 : statusLower.includes("Almost Full") ||
//                   statusLower.includes("high")
//                 ? AlmostFullIcon
//                 : statusLower.includes("Full")
//                 ? FullIcon
//                 : statusLower.includes("Empty")
//                 ? EmptyIcon
//                 : SafeIcon
//             }
//             alt={status || "status"}
//             className="dash3-icon badge-icon"
//           />
//           <div className="dash3-status-text">
//             {status
//               ? statusLower.includes("safe")
//                 ? "Safe to Enter"
//                 : status
//               : "..."}
//           </div>
//         </div>
//       </div>

//       {/* Chart + Side Stats */}
//       <div className="dash3-bottom-row">
//         <div className="dash3-chart-section">
//           <h3>Hourly Trends</h3>

//           <div className="chart-container">
//             <ResponsiveContainer width="100%" height={440} tabIndex={-1}>
//               <AreaChart
//                 data={hourly}
//                 margin={{ top: 10, right: 20, left: 0, bottom: 0 }}
//               >
//                 <defs>
//                   <linearGradient id="fill2" x1="0" y1="0" x2="0" y2="1">
//                     <stop offset="10%" stopColor="#1d4ed8" stopOpacity={0.18} />
//                     <stop offset="95%" stopColor="#1d4ed8" stopOpacity={0} />
//                   </linearGradient>
//                 </defs>
//                 <CartesianGrid
//                   strokeDasharray="3 3"
//                   vertical={false}
//                   stroke="#e5e7eb"
//                 />
//                 <XAxis
//                   dataKey="Hours"
//                   tick={{ fontSize: 12 }}
//                   interval={0}
//                   angle={-25}
//                   textAnchor="end"
//                   height={60}
//                   tickFormatter={(value) => {
//                     const [h, m] = value.split(":");
//                     return m === "00" ? `${h}:00` : "";
//                   }}
//                   label={{
//                     value: "HOURS",
//                     position: "insideBottom",
//                     offset: 0,
//                     fill: "#4b5563",
//                     fontSize: 13,
//                     fontWeight: 600,
//                   }}
//                 />
//                 <YAxis
//                   tick={{ fontSize: 12 }}
//                   width={60}
//                   label={{
//                     value: "COUNTS",
//                     angle: -90,
//                     position: "insideLeft",
//                     fill: "#4b5563",
//                     fontSize: 13,
//                     fontWeight: 600,
//                   }}
//                 />
//                 <Tooltip
//                   content={({ active, payload, label }) => {
//                     if (active && payload && payload.length) {
//                       const val = payload[0].value;
//                       return (
//                         <div
//                           style={{
//                             background: "#fff",
//                             border: "1px solid #d1d5db",
//                             borderRadius: 8,
//                             padding: "8px 10px",
//                             fontSize: 13,
//                           }}
//                         >
//                           <div>
//                             <strong>Hour:</strong> {label}
//                           </div>
//                           <div>
//                             <strong>Live Occupancy:</strong> {val}
//                           </div>
//                         </div>
//                       );
//                     }
//                     return null;
//                   }}
//                   cursor={{ strokeDasharray: "4 4", stroke: "#111827" }}
//                 />
//                 <Area
//                   type="monotone"
//                   dataKey="LiveOccupancy"
//                   stroke="#1d4ed8"
//                   fill="url(#fill2)"
//                   strokeWidth={3}
//                   dot={{ r: 4 }}
//                   activeDot={{ r: 6 }}
//                 />
//                 <Line
//                   type="monotone"
//                   dataKey="value"
//                   stroke="#1d4ed8"
//                   strokeWidth={2}
//                   dot={{
//                     r: 4,
//                     fill: "#1d4ed8",
//                     stroke: "#fff",
//                     strokeWidth: 2,
//                   }}
//                   activeDot={{ r: 6 }}
//                   isAnimationActive={true}
//                   animationDuration={800}
//                 />
//               </AreaChart>
//             </ResponsiveContainer>

//             {refreshing && <div className="chart-overlay">Updating…</div>}
//           </div>

//           <div className="dash3-chart-footer">
//             <span>
//               <img
//                 src={TotalInIcon}
//                 width="22px"
//                 height="22px"
//                 className="total-icon"
//               />
//               Total In :{" "}
//               <strong className="dash3-in">
//                 <AnimatedNumber value={data?.totals?.Totalin} />
//               </strong>
//             </span>
//             <span>
//               <img
//                 src={TotalOutIcon}
//                 width="22px"
//                 height="22px"
//                 className="total-icon"
//               />
//               Total Out :{" "}
//               <strong className="dash3-out">
//                 <AnimatedNumber value={data?.totals?.Totalout} />
//               </strong>
//             </span>
//           </div>
//         </div>

//         <div className="dash3-side-grid">
//           <StatSideCard icon={RemainingCapacityIcon} label="Remaining Capacity">
//             <AnimatedNumber value={data?.capacityStats?.Remainingcapacity} />
//           </StatSideCard>
//           <StatSideCard icon={PeakOccIcon} label="Peak Occupancy">
//             <AnimatedNumber value={data?.peakStats?.Peakoccupancy} />
//           </StatSideCard>
//           <StatSideCard icon={PeakHourIcon} label="Peak Hour">
//             {data?.peakStats?.Peakhour ?? "--"}{" "}
//             <span className="dash3-hr-suffix">Hr</span>
//           </StatSideCard>
//         </div>
//       </div>
//       <Footer />
//     </div>
//   );
// }

// /* --- Reusable Components --- */
// function StatCard({ icon, label, children }) {
//   return (
//     <div className="dash3-stat-card">
//       <div className="cardsec1">
//         <img src={icon} alt={label} className="dash3-icon" />
//         <div className="dash3-stat-main">{children}</div>
//       </div>
//       <div className="dash3-stat-label">{label}</div>
//     </div>
//   );
// }

// function StatSideCard({ icon, label, children }) {
//   return (
//     <div className="dash3-side-card">
//       <div className="cardsec1">
//         <img src={icon} alt={label} className="dash3-icon" />
//         <div className="dash3-side-main">{children}</div>
//       </div>
//       <div className="dash3-side-label">{label}</div>
//     </div>
//   );
// }

// function AnimatedNumber({ value, duration = 600, suffix = "" }) {
//   const [display, setDisplay] = useState(value ?? 0);
//   const prevRef = React.useRef(value ?? 0);

//   useEffect(() => {
//     if (value == null || value === prevRef.current) return;
//     const start = performance.now();
//     const from = prevRef.current || 0;
//     const to = value || 0;
//     const d = duration;
//     function ease(p) {
//       return p < 0.5 ? 2 * p * p : -1 + (4 - 2 * p) * p;
//     }
//     function step(ts) {
//       const p = Math.min(1, (ts - start) / d);
//       const eased = ease(p);
//       const current = from + (to - from) * eased;
//       setDisplay(Math.round(current));
//       if (p < 1) requestAnimationFrame(step);
//       else prevRef.current = to;
//     }
//     requestAnimationFrame(step);
//   }, [value, duration]);

//   return value == null ? (
//     <span className="animated-number">--</span>
//   ) : (
//     <span className="animated-number">
//       {display}
//       {suffix}
//     </span>
//   );
// }
import React, { useCallback, useEffect, useMemo, useState } from "react";
import { fetchZones, fetchDashboard } from "./api";
import {
  XAxis,
  YAxis,
  Tooltip,
  ResponsiveContainer,
  ReferenceLine,
  CartesianGrid,
  Area,
  Line,
  AreaChart,
} from "recharts";
import "./Dashboard.css";

// Assets
import OccupancyIcon from "../../components/Assets/dashboard/sv_occupancy.svg";
import CapacityIcon from "../../components/Assets/dashboard/sv_capcity.svg";
import PercentageIcon from "../../components/Assets/dashboard/sv_percentage.svg";
import SafeIcon from "../../components/Assets/dashboard/sv_safetoenter.svg";
import AlmostFullIcon from "../../components/Assets/dashboard/sv_allmostfull.svg";
import FullIcon from "../../components/Assets/dashboard/sv_full.svg";
import EmptyIcon from "../../components/Assets/dashboard/sv_empty.svg";
import RemainingCapacityIcon from "../../components/Assets/dashboard/sv_remainingcapacity.svg";
import PeakOccIcon from "../../components/Assets/dashboard/sv_peakoccupancy.svg";
import PeakHourIcon from "../../components/Assets/dashboard/sv_peakhour.svg";
import TotalInIcon from "../../components/Assets/dashboard/total-in.svg";
import TotalOutIcon from "../../components/Assets/dashboard/total-out.svg";
import Footer from "../CommonComponents/Footer";
import SingleSelectDropdown from "../CommonComponents/SingleSelectDropdown"; // ✅ Import dropdown

export default function Dashboard() {
  const [token, setToken] = useState(null);
  const [zones, setZones] = useState([]);
  const [zoneIndex, setZoneIndex] = useState(0);
  const [data, setData] = useState(null);
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);
  const [error, setError] = useState(null);

  const activeZone = zones[zoneIndex];

  // 🔑 Load token + zones on mount
  useEffect(() => {
    let mounted = true;
    (async () => {
      try {
        const userData = JSON.parse(sessionStorage.getItem("userData"));
        if (!userData?.token) {
          throw new Error("Missing session token, please log in again");
        }

        if (!mounted) return;
        setToken(userData.token);

        const z = await fetchZones(
          userData.token,
          userData.user.vid,
          userData.user.username
        );
        if (!mounted) return;
        setZones(z);
      } catch (e) {
        if (mounted) setError(e.message);
      }
    })();
    return () => {
      mounted = false;
    };
  }, []);

  // 📊 Load dashboard data
  const loadData = useCallback(
    async (zone, isRefresh = false) => {
      if (!token || !zone) return;
      if (isRefresh) setRefreshing(true);
      else setLoading(true);

      setError(null);
      try {
        const d = await fetchDashboard(token, zone);
        setData(d);
      } catch (e) {
        setError(e.message);
      } finally {
        if (isRefresh) setRefreshing(false);
        else setLoading(false);
      }
    },
    [token]
  );
// 🔄 Auto-rotate zones every 15s
useEffect(() => {
  if (!zones.length) return;

  const id = setInterval(() => {
    setZoneIndex((prev) => (prev + 1) % zones.length);
  }, 15000);

  return () => clearInterval(id);
}, [zones.length]);
  // Load data when token or zone changes
  useEffect(() => {
    if (token && activeZone) {
      loadData(activeZone);
    }
  }, [token, activeZone, loadData]);

  // 🔄 Refresh dashboard data every 15s
  useEffect(() => {
    if (!token || !activeZone) return;

    const id = setInterval(() => {
      loadData(activeZone, true);
    }, 15000);

    return () => clearInterval(id);
  }, [token, activeZone, loadData]);

  // 🔄 Refresh zones list every 15s (auto-update dropdown)
  useEffect(() => {
    if (!token) return;

    let mounted = true;
    const userData = JSON.parse(sessionStorage.getItem("userData"));
    if (!userData) return;

    const fetchAndSetZones = async () => {
      try {
        const z = await fetchZones(
          token,
          userData.user.vid,
          userData.user.username
        );

        if (mounted && Array.isArray(z)) {
          setZones((prevZones) => {
            if (JSON.stringify(prevZones) !== JSON.stringify(z)) {
              return z;
            }
            return prevZones;
          });

          setZoneIndex((prevIndex) => {
            if (z.length === 0) return 0;
            return Math.min(prevIndex, z.length - 1);
          });
        }
      } catch (e) {
        console.error("Failed to refresh zones", e.message);
      }
    };

    fetchAndSetZones();
    const id = setInterval(fetchAndSetZones, 15000);

    return () => {
      mounted = false;
      clearInterval(id);
    };
  }, [token]);

  // ✅ Dropdown options
  const zoneOptions = useMemo(
    () => zones.map((z, i) => ({ value: i, label: z })),
    [zones]
  );

  const hourly = useMemo(() => data?.hourlyData || [], [data]);
  const status = data?.peakStats?.Status || "";
  const statusLower = status;
  let badgeCls = "badge-safe";
  if (statusLower.includes("Almost Full")) {
    badgeCls = "badge-almost";
  } else if (statusLower.includes("Full")) {
    badgeCls = "badge-full";
  } else if (statusLower.includes("Empty")) {
    badgeCls = "badge-empty";
  } else if (statusLower.includes("Safe to Enter")) {
    badgeCls = "badge-safe";
  }

  return (
    <div className="dashboard-wrapper">
      <div className="single_dashboard-header">
        <div className="dashboard-projectTitle">
          <h3 className="mb-0">
            Occupancy<span>2.0</span>
          </h3>
        </div>

        <div className="dashboard-title">
          <h2 className="mb-0">{activeZone || "--"}</h2>
        </div>

        <div className="zone-selector">
          <label>Zone</label>
          <SingleSelectDropdown
            options={zoneOptions}
            value={zoneOptions.find((o) => o.value === zoneIndex) || null}
            onChange={(option) => setZoneIndex(option ? option.value : 0)}
            placeholder="Select Zone"
            className="singlezoneDropdown"
          />
        </div>
      </div>

      {error && <div className="error-banner">{error}</div>}

      {/* Stats Grid */}
      <div className="dash3-stat-grid">
        <StatCard icon={OccupancyIcon} label="Live Occupancy">
          <AnimatedNumber value={data?.liveStats?.LiveOccupancy} />
        </StatCard>
        <StatCard icon={CapacityIcon} label="Max Capacity">
          <AnimatedNumber value={data?.capacityStats?.Maxcapacity} />
        </StatCard>
        <StatCard icon={PercentageIcon} label="Percentage ">
          <AnimatedNumber value={data?.liveStats?.Percentage} suffix="%" />
        </StatCard>

        <div className={`dash3-status-badge ${badgeCls}`}>
          <img
            src={
              statusLower.includes("Safe to Enter")
                ? SafeIcon
                : statusLower.includes("Almost Full") ||
                  statusLower.includes("high")
                ? AlmostFullIcon
                : statusLower.includes("Full")
                ? FullIcon
                : statusLower.includes("Empty")
                ? EmptyIcon
                : SafeIcon
            }
            alt={status || "status"}
            className="dash3-icon badge-icon"
          />
          <div className="dash3-status-text">
            {status
              ? statusLower.includes("safe")
                ? "Safe to Enter"
                : status
              : "..."}
          </div>
        </div>
      </div>

      {/* Chart + Side Stats */}
      <div className="dash3-bottom-row">
        <div className="dash3-chart-section">
          <h3>Hourly Trends</h3>

          <div className="chart-container">
            <ResponsiveContainer width="100%" height={440} tabIndex={-1}>
              <AreaChart
                data={hourly}
                margin={{ top: 10, right: 20, left: 0, bottom: 0 }}
              >
                <defs>
                  <linearGradient id="fill2" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="10%" stopColor="#1d4ed8" stopOpacity={0.18} />
                    <stop offset="95%" stopColor="#1d4ed8" stopOpacity={0} />
                  </linearGradient>
                </defs>
                <CartesianGrid
                  strokeDasharray="3 3"
                  vertical={false}
                  stroke="#e5e7eb"
                />
                <XAxis
                  dataKey="Hours"
                  tick={{ fontSize: 12 }}
                  interval={0}
                  angle={-25}
                  textAnchor="end"
                  height={60}
                  tickFormatter={(value) => {
                    const [h, m] = value.split(":");
                    return m === "00" ? `${h}:00` : "";
                  }}
                  label={{
                    value: "HOURS",
                    position: "insideBottom",
                    offset: 0,
                    fill: "#4b5563",
                    fontSize: 13,
                    fontWeight: 600,
                  }}
                />
                <YAxis
                  tick={{ fontSize: 12 }}
                  width={60}
                  label={{
                    value: "COUNTS",
                    angle: -90,
                    position: "insideLeft",
                    fill: "#4b5563",
                    fontSize: 13,
                    fontWeight: 600,
                  }}
                />
                <Tooltip
                  content={({ active, payload, label }) => {
                    if (active && payload && payload.length) {
                      const val = payload[0].value;
                      return (
                        <div
                          style={{
                            background: "#fff",
                            border: "1px solid #d1d5db",
                            borderRadius: 8,
                            padding: "8px 10px",
                            fontSize: 13,
                          }}
                        >
                          <div>
                            <strong>Hour:</strong> {label}
                          </div>
                          <div>
                            <strong>Live Occupancy:</strong> {val}
                          </div>
                        </div>
                      );
                    }
                    return null;
                  }}
                  cursor={{ strokeDasharray: "4 4", stroke: "#111827" }}
                />
                <Area
                  type="monotone"
                  dataKey="LiveOccupancy"
                  stroke="#1d4ed8"
                  fill="url(#fill2)"
                  strokeWidth={3}
                  dot={{ r: 4 }}
                  activeDot={{ r: 6 }}
                />
                <Line
                  type="monotone"
                  dataKey="value"
                  stroke="#1d4ed8"
                  strokeWidth={2}
                  dot={{
                    r: 4,
                    fill: "#1d4ed8",
                    stroke: "#fff",
                    strokeWidth: 2,
                  }}
                  activeDot={{ r: 6 }}
                  isAnimationActive={true}
                  animationDuration={800}
                />
              </AreaChart>
            </ResponsiveContainer>

            {refreshing && <div className="chart-overlay">Updating…</div>}
          </div>

          <div className="dash3-chart-footer">
            <span>
              <img
                src={TotalInIcon}
                width="22px"
                height="22px"
                className="total-icon"
              />
              Total In :{" "}
              <strong className="dash3-in">
                <AnimatedNumber value={data?.totals?.Totalin} />
              </strong>
            </span>
            <span>
              <img
                src={TotalOutIcon}
                width="22px"
                height="22px"
                className="total-icon"
              />
              Total Out :{" "}
              <strong className="dash3-out">
                <AnimatedNumber value={data?.totals?.Totalout} />
              </strong>
            </span>
          </div>
        </div>

        <div className="dash3-side-grid">
          <StatSideCard icon={RemainingCapacityIcon} label="Remaining Capacity">
            <AnimatedNumber value={data?.capacityStats?.Remainingcapacity} />
          </StatSideCard>
          <StatSideCard icon={PeakOccIcon} label="Peak Occupancy">
            <AnimatedNumber value={data?.peakStats?.Peakoccupancy} />
          </StatSideCard>
          <StatSideCard icon={PeakHourIcon} label="Peak Hour">
            {data?.peakStats?.Peakhour ?? "--"}{" "}
            <span className="dash3-hr-suffix">Hr</span>
          </StatSideCard>
        </div>
      </div>
      <Footer />
    </div>
  );
}

/* --- Reusable Components --- */
function StatCard({ icon, label, children }) {
  return (
    <div className="dash3-stat-card">
      <div className="cardsec1">
        <img src={icon} alt={label} className="dash3-icon" />
        <div className="dash3-stat-main">{children}</div>
      </div>
      <div className="dash3-stat-label">{label}</div>
    </div>
  );
}

function StatSideCard({ icon, label, children }) {
  return (
    <div className="dash3-side-card">
      <div className="cardsec1">
        <img src={icon} alt={label} className="dash3-icon" />
        <div className="dash3-side-main">{children}</div>
      </div>
      <div className="dash3-side-label">{label}</div>
    </div>
  );
}

function AnimatedNumber({ value, duration = 600, suffix = "" }) {
  const [display, setDisplay] = useState(value ?? 0);
  const prevRef = React.useRef(value ?? 0);

  useEffect(() => {
    if (value == null || value === prevRef.current) return;
    const start = performance.now();
    const from = prevRef.current || 0;
    const to = value || 0;
    const d = duration;
    function ease(p) {
      return p < 0.5 ? 2 * p * p : -1 + (4 - 2 * p) * p;
    }
    function step(ts) {
      const p = Math.min(1, (ts - start) / d);
      const eased = ease(p);
      const current = from + (to - from) * eased;
      setDisplay(Math.round(current));
      if (p < 1) requestAnimationFrame(step);
      else prevRef.current = to;
    }
    requestAnimationFrame(step);
  }, [value, duration]);

  return value == null ? (
    <span className="animated-number">--</span>
  ) : (
    <span className="animated-number">
      {display}
      {suffix}
    </span>
  );
}
