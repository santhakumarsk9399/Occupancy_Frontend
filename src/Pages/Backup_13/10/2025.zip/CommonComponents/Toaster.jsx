// src/components/Common/Toaster.js
import { toast, ToastContainer } from "react-toastify";
import "react-toastify/dist/ReactToastify.css";
import "../../Components/Styles/ToastOverride.css";

// helper functions
export const showSuccess = (msg) => {
  console.log("showSuccess called with:", msg);
  toast.success(msg, { position: "top-right" });
};

export const showError = (msg) => {
  console.log("showError called with:", msg);
  toast.error(msg, { position: "top-right" });
};

export const showInfo = (msg) => {
  console.log("showInfo called with:", msg);
  toast.info(msg, { position: "top-right" });
};

// toaster container (must render once in App.js)
export const ToasterContainer = () => (
  <ToastContainer
    position="top-right"
    autoClose={3000}
    hideProgressBar={false}
    newestOnTop
    closeOnClick
    draggable
    pauseOnHover={false}
    pauseOnFocusLoss={false}
    theme="light"
    style={{ 
      zIndex: 99999,
      position: 'fixed',
      top: '20px',
      right: '20px'
    }}
    toastStyle={{ 
      textAlign: 'center',
      fontSize: '14px',
      borderRadius: '8px',
      minHeight: '50px'
    }}
  />
);
