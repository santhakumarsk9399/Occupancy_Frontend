import React from 'react'

const ZonewiseTab = () => {
  return (
    <div>ZonewiseTab</div>
  )
}

export default ZonewiseTab