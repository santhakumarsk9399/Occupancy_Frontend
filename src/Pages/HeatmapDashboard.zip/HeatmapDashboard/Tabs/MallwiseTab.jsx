

// export default function MallwiseTab() {
//   const [selectedMall] = useState(mallsData[0]);

//   const [selectedFloor, setSelectedFloor] = useState(
//     mallsData[0].floors[0]
//   );

//   const [zoom, setZoom] = useState(1);

//   const [timelineHour, setTimelineHour] = useState(14);

//   const [gradientType, setGradientType] =
//     useState("default");

//   const mapRef = useRef(null);

//   const hours = useMemo(
//     () => [9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19],
//     []
//   );

//   /* =========================
//      IMAGE RENDER SIZE
//   ========================= */

//   const renderWidth = 780;

//   const renderHeight = 1300;

//   const scaleX =
//     renderWidth / selectedFloor.imageW;

//   const scaleY =
//     renderHeight / selectedFloor.imageH;

//   return (
//     <div className="mallwise-layout">
//       {/* LEFT PANEL */}

//       <div className="left-panel">
//         <div className="filter-card">
//           <div className="field-group">
//             <label>Mall</label>

//             <select>
//               <option>
//                 {selectedMall.mallName}
//               </option>
//             </select>
//           </div>

//           <div className="field-group">
//             <label>Floor</label>

//             <div className="floor-list">
//               {selectedMall.floors.map((floor) => (
//                 <div
//                   key={floor.floorId}
//                   className={`floor-item ${selectedFloor.floorId ===
//                       floor.floorId
//                       ? "active-floor"
//                       : ""
//                     }`}
//                   onClick={() =>
//                     setSelectedFloor(floor)
//                   }
//                 >
//                   <span>{floor.floorName}</span>

//                   <span className="floor-badge">
//                     {floor.visitors}
//                   </span>
//                 </div>
//               ))}
//             </div>
//           </div>
//         </div>

//         <div className="stats-card">
//           <div className="stats-value">
//             14,067
//           </div>

//           <div className="stats-title">
//             Total Visitors
//           </div>

//           <div className="stats-footer">
//             <span>Yesterday</span>

//             <span className="positive">
//               ↗ 4.2%
//             </span>
//           </div>
//         </div>

//         <div className="stats-card">
//           <div className="stats-value">
//             1,631
//           </div>

//           <div className="stats-title">
//             Visitors Inside
//           </div>

//           <div className="stats-footer">
//             <span>Last hour</span>

//             <span className="negative">
//               ↙ 6.5%
//             </span>
//           </div>
//         </div>

//         <div className="stats-card">
//           <div className="stats-value">
//             12:30
//           </div>

//           <div className="stats-title">
//             Peak Hour
//           </div>

//           <div className="stats-footer">
//             <span>1,091 Visitors</span>
//           </div>
//         </div>

//         <div className="stats-card">
//           <div className="stats-value">
//             29min
//           </div>

//           <div className="stats-title">
//             Avg Dwell Time
//           </div>

//           <div className="stats-footer">
//             <span>Yesterday</span>

//             <span className="negative">
//               ↙ 7.5%
//             </span>
//           </div>
//         </div>
//       </div>

//       {/* RIGHT PANEL */}

//       <div className="right-panel">
//         <div className="heatmap-card">
//           {/* HEADER */}

//           <div className="heatmap-topbar">
//             <div className="breadcrumb">
//               <span>
//                 🏢 {selectedMall.mallName}
//               </span>

//               <span>
//                 🏬 {selectedFloor.floorName}
//               </span>
//             </div>

//             <button className="fullscreen-btn">
//               ⛶
//             </button>
//           </div>

//           {/* LEGEND */}

//           <div className="legend-section">
//             <span className="legend-label">
//               Occupancy
//             </span>

//             <div className="legend-bar" />

//             <div className="legend-range">
//               <span>0%</span>

//               <span>100%</span>
//             </div>
//           </div>

//           {/* MAP */}

//           <div className="map-wrapper">
//             <div className="map-scroll">
//               <div
//                 className="map-inner"
//                 ref={mapRef}
//                 style={{
//                   width: renderWidth,
//                   height: renderHeight,
//                   transform: `scale(${zoom})`,
//                 }}
//               >
//                 {/* IMAGE */}

//                 <img
//                   src={selectedFloor.floorImage}
//                   alt=""
//                   className="floor-image"
//                 />

//                 {/* HEATMAP */}

//                 {selectedFloor.zones.map(
//                   (zone) => {
//                     // CENTER POINT
//                     const centerX =
//                       zone.points.reduce(
//                         (sum, p) =>
//                           sum + p.x,
//                         0
//                       ) /
//                       zone.points.length;

//                     const centerY =
//                       zone.points.reduce(
//                         (sum, p) =>
//                           sum + p.y,
//                         0
//                       ) /
//                       zone.points.length;

//                     // SCALE
//                     const mappedX =
//                       centerX * scaleX;

//                     const mappedY =
//                       centerY * scaleY;

//                     // OCCUPANCY
//                     const occupancy =
//                       Math.max(
//                         0,
//                         Math.min(
//                           100,
//                           zone.occupancy +
//                           (timelineHour -
//                             14) *
//                           2
//                         )
//                       );

//                     // HEAT SIZE
//                     const heatSize =
//                       occupancy >= 90
//                         ? 430
//                         : occupancy >= 70
//                           ? 360
//                           : occupancy >= 50
//                             ? 300
//                             : 240;

//                     return (
//                       <React.Fragment
//                         key={zone.zoneId}
//                       >
//                         {/* HEAT */}

//                         <div
//                           className={`heat-glow ${gradientType
//                             }`}
//                           style={{
//                             width: heatSize,
//                             height: heatSize,

//                             left: mappedX,
//                             top: mappedY,

//                             opacity:
//                               occupancy / 100,
//                           }}
//                         />

//                         {/* LABEL */}

//                         <div
//                           className="zone-label"
//                           style={{
//                             left: mappedX,
//                             top: mappedY,
//                           }}
//                         >
//                           <h4>
//                             {zone.zoneName}
//                           </h4>

//                           <p>
//                             {occupancy}%
//                           </p>
//                         </div>
//                       </React.Fragment>
//                     );
//                   }
//                 )}
//               </div>
//             </div>

//             {/* TOOLS */}

//             <div className="map-tools">
//               <button
//                 onClick={() =>
//                   setZoom((p) => p + 0.1)
//                 }
//               >
//                 +
//               </button>

//               <button
//                 onClick={() =>
//                   setZoom((p) =>
//                     Math.max(0.7, p - 0.1)
//                   )
//                 }
//               >
//                 −
//               </button>

//               <div
//                 className="gradient-tool first"
//                 onClick={() =>
//                   setGradientType(
//                     "default"
//                   )
//                 }
//               />

//               <div
//                 className="gradient-tool second"
//                 onClick={() =>
//                   setGradientType(
//                     "purple"
//                   )
//                 }
//               />
//             </div>

//             {/* TIMELINE */}

//             <div className="timeline-container">
//               <input
//                 type="range"
//                 min="9"
//                 max="19"
//                 value={timelineHour}
//                 onChange={(e) =>
//                   setTimelineHour(
//                     Number(e.target.value)
//                   )
//                 }
//               />

//               <div className="timeline-hours">
//                 {hours.map((hour) => (
//                   <span key={hour}>
//                     {hour}
//                   </span>
//                 ))}
//               </div>
//             </div>
//           </div>
//         </div>
//       </div>
//     </div>
//   );
// }


import React, {
  useMemo,
  useRef,
  useState,
} from "react";

import "../Styles/mallwiseTab.css";

import floorImage from "../../../../public/hm46full.png";

// const mallsData = [
//   {
//     mallId: 1,
//     mallName: "Nexus Mall - BLR",

//     floors: [
//       {
//         floorId: 1,
//         floorName: "Ground Floor",
//         visitors: 14067,

//         imageW: 5467,
//         imageH: 3164,

//         floorImage: floorImage,

//         zones: [
//           {
//             zoneId: 1,
//             zoneName: "Fashion Zone",
//             occupancy: 92,

//             points: [
//               { x: 1600, y: 1928 },
//               { x: 1855, y: 1713 },
//               { x: 2110, y: 1703 },
//               { x: 2320, y: 1823 },
//               { x: 2455, y: 2033 },
//               { x: 2470, y: 2268 },
//               { x: 2415, y: 2428 },
//               { x: 2265, y: 2518 },
//               { x: 2145, y: 2568 },
//               { x: 2015, y: 2618 },
//               { x: 1900, y: 2618 },
//               { x: 1705, y: 2518 },
//               { x: 1625, y: 2318 },
//               { x: 1525, y: 2078 },
//             ],
//           },

//           {
//             zoneId: 2,
//             zoneName: "Electronics Zone",
//             occupancy: 78,

//             points: [
//               { x: 3430, y: 303 },
//               { x: 3500, y: 285 },
//               { x: 3783, y: 286 },
//               { x: 3876, y: 284 },
//               { x: 4261, y: 288 },
//               { x: 4274, y: 368 },
//               { x: 4126, y: 482 },
//               { x: 3504, y: 458 },
//             ],
//           },

//           {
//             zoneId: 3,
//             zoneName: "Zone A",
//             occupancy: 45,

//             points: [
//               { x: 3175, y: 257 },
//               { x: 3245, y: 243 },
//               { x: 3320, y: 273 },
//               { x: 3365, y: 355 },
//               { x: 3344, y: 439 },
//               { x: 3278, y: 500 },
//             ],
//           },
//         ],
//       },
//     ],
//   },
// ];
const mallsData = [
  {
    mallId: 1,
    mallName: "Nexus Mall - BLR",

    floors: [
      {
        floorId: 1,
        floorName: "Ground Floor",
        visitors: 14067,

        imageW: 5467,
        imageH: 3164,

        floorImage: floorImage,

        zones: [
          {
            zoneId: 1,
            zoneName: "Fashion Zone",
            occupancy: 92,

            points: [
              { x: 1600, y: 1928 },
              { x: 1855, y: 1713 },
              { x: 2110, y: 1703 },
              { x: 2320, y: 1823 },
              { x: 2455, y: 2033 },
              { x: 2470, y: 2268 },
              { x: 2415, y: 2428 },
              { x: 2265, y: 2518 },
              { x: 2145, y: 2568 },
              { x: 2015, y: 2618 },
            ],
          },

          {
            zoneId: 2,
            zoneName: "Electronics Zone",
            occupancy: 78,

            points: [
              { x: 3430, y: 303 },
              { x: 3500, y: 285 },
              { x: 3783, y: 286 },
              { x: 3876, y: 284 },
              { x: 4261, y: 288 },
              { x: 4274, y: 368 },
            ],
          },

          {
            zoneId: 3,
            zoneName: "Gaming Zone",
            occupancy: 45,

            points: [
              { x: 3175, y: 257 },
              { x: 3245, y: 243 },
              { x: 3320, y: 273 },
              { x: 3365, y: 355 },
            ],
          },
        ],
      },

      {
        floorId: 2,
        floorName: "First Floor",
        visitors: 8560,

        imageW: 5467,
        imageH: 3164,

        floorImage: floorImage,

        zones: [
          {
            zoneId: 4,
            zoneName: "Food Court",
            occupancy: 88,

            points: [
              { x: 900, y: 2300 },
              { x: 1120, y: 2220 },
              { x: 1380, y: 2350 },
              { x: 1420, y: 2580 },
            ],
          },

          {
            zoneId: 5,
            zoneName: "Luxury Brands",
            occupancy: 61,

            points: [
              { x: 3900, y: 1100 },
              { x: 4250, y: 1050 },
              { x: 4380, y: 1340 },
              { x: 4010, y: 1420 },
            ],
          },
        ],
      },

      {
        floorId: 3,
        floorName: "Second Floor",
        visitors: 6210,

        imageW: 5467,
        imageH: 3164,

        floorImage: floorImage,

        zones: [
          {
            zoneId: 6,
            zoneName: "Kids Area",
            occupancy: 72,

            points: [
              { x: 2200, y: 1450 },
              { x: 2520, y: 1420 },
              { x: 2680, y: 1710 },
              { x: 2310, y: 1780 },
            ],
          },

          {
            zoneId: 7,
            zoneName: "Cinema Lobby",
            occupancy: 54,

            points: [
              { x: 4520, y: 2050 },
              { x: 4860, y: 1980 },
              { x: 5030, y: 2320 },
              { x: 4620, y: 2400 },
            ],
          },
        ],
      },
    ],
  },

  {
    mallId: 2,
    mallName: "Phoenix Mall - MUM",

    floors: [
      {
        floorId: 4,
        floorName: "Ground Floor",
        visitors: 18900,

        imageW: 5467,
        imageH: 3164,

        floorImage: floorImage,

        zones: [
          {
            zoneId: 8,
            zoneName: "Retail Street",
            occupancy: 84,

            points: [
              { x: 1200, y: 720 },
              { x: 1540, y: 700 },
              { x: 1680, y: 960 },
              { x: 1310, y: 1040 },
            ],
          },

          {
            zoneId: 9,
            zoneName: "Dining Zone",
            occupancy: 73,

            points: [
              { x: 3100, y: 2200 },
              { x: 3460, y: 2140 },
              { x: 3520, y: 2480 },
              { x: 3220, y: 2580 },
            ],
          },
        ],
      },

      {
        floorId: 5,
        floorName: "First Floor",
        visitors: 10210,

        imageW: 5467,
        imageH: 3164,

        floorImage: floorImage,

        zones: [
          {
            zoneId: 10,
            zoneName: "Entertainment",
            occupancy: 91,

            points: [
              { x: 4200, y: 520 },
              { x: 4520, y: 500 },
              { x: 4660, y: 780 },
              { x: 4320, y: 860 },
            ],
          },

          {
            zoneId: 11,
            zoneName: "Cafe Area",
            occupancy: 58,

            points: [
              { x: 2000, y: 2620 },
              { x: 2280, y: 2550 },
              { x: 2410, y: 2780 },
              { x: 2080, y: 2920 },
            ],
          },
        ],
      },
    ],
  },

  {
    mallId: 3,
    mallName: "Forum Mall - CHN",

    floors: [
      {
        floorId: 6,
        floorName: "Ground Floor",
        visitors: 15440,

        imageW: 5467,
        imageH: 3164,

        floorImage: floorImage,

        zones: [
          {
            zoneId: 12,
            zoneName: "Hyper Market",
            occupancy: 95,

            points: [
              { x: 2600, y: 1200 },
              { x: 3040, y: 1180 },
              { x: 3160, y: 1520 },
              { x: 2740, y: 1610 },
            ],
          },

          {
            zoneId: 13,
            zoneName: "Perfume Zone",
            occupancy: 66,

            points: [
              { x: 620, y: 1880 },
              { x: 980, y: 1810 },
              { x: 1060, y: 2100 },
              { x: 720, y: 2220 },
            ],
          },
        ],
      },

      {
        floorId: 7,
        floorName: "Food Court",
        visitors: 9310,

        imageW: 5467,
        imageH: 3164,

        floorImage: floorImage,

        zones: [
          {
            zoneId: 14,
            zoneName: "South Dining",
            occupancy: 87,

            points: [
              { x: 3600, y: 2380 },
              { x: 3920, y: 2320 },
              { x: 4050, y: 2600 },
              { x: 3710, y: 2710 },
            ],
          },

          {
            zoneId: 15,
            zoneName: "Coffee Hub",
            occupancy: 49,

            points: [
              { x: 1500, y: 900 },
              { x: 1780, y: 860 },
              { x: 1860, y: 1140 },
              { x: 1590, y: 1220 },
            ],
          },
        ],
      },

      {
        floorId: 8,
        floorName: "Third Floor",
        visitors: 7100,

        imageW: 5467,
        imageH: 3164,

        floorImage: floorImage,

        zones: [
          {
            zoneId: 16,
            zoneName: "VR Gaming",
            occupancy: 82,

            points: [
              { x: 4420, y: 1420 },
              { x: 4720, y: 1380 },
              { x: 4850, y: 1650 },
              { x: 4510, y: 1760 },
            ],
          },

          {
            zoneId: 17,
            zoneName: "Book Store",
            occupancy: 41,

            points: [
              { x: 2300, y: 600 },
              { x: 2580, y: 580 },
              { x: 2700, y: 860 },
              { x: 2410, y: 920 },
            ],
          },
        ],
      },
    ],
  },
];
export default function MallwiseTab() {
  const [selectedMall, setSelectedMall] =
    useState(mallsData[0]);

  const [selectedFloor, setSelectedFloor] =
    useState(mallsData[0].floors[0]);

  const [zoom, setZoom] = useState(1);

  const [timelineHour, setTimelineHour] =
    useState(14);

  const [gradientType, setGradientType] =
    useState("default");
  const [isFullscreen, setIsFullscreen] = useState(false);
  const mapRef = useRef(null);

  const hours = useMemo(
    () => [9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19],
    []
  );

  const renderWidth =
    selectedFloor.imageW * zoom;

  const renderHeight =
    selectedFloor.imageH * zoom;

  return (
    <div className="mallwise-layout">

      {/* LEFT PANEL */}

      <div className="left-panel">

        <div className="filter-card">

          <div className="field-group">

            <label>Mall</label>

            <select
              value={selectedMall.mallId}
              onChange={(e) => {

                const mall =
                  mallsData.find(
                    (m) =>
                      m.mallId ===
                      Number(e.target.value)
                  );

                setSelectedMall(mall);

                setSelectedFloor(
                  mall.floors[0]
                );
              }}
            >

              {mallsData.map((mall) => (
                <option
                  key={mall.mallId}
                  value={mall.mallId}
                >
                  {mall.mallName}
                </option>
              ))}

            </select>

          </div>

          <div className="field-group">

            <label>Floor</label>

            <div className="floor-list">

              {selectedMall.floors.map(
                (floor) => (

                  <div
                    key={floor.floorId}
                    className={`floor-item ${selectedFloor.floorId ===
                        floor.floorId
                        ? "active-floor"
                        : ""
                      }`}
                    onClick={() =>
                      setSelectedFloor(floor)
                    }
                  >

                    <span>
                      {floor.floorName}
                    </span>

                    <span className="floor-badge">
                      {floor.visitors}
                    </span>

                  </div>
                )
              )}

            </div>

          </div>

        </div>

        <div className="stats-card">
          <div className="stats-value">
            14,067
          </div>

          <div className="stats-title">
            Total Visitors
          </div>

          <div className="stats-footer">
            <span>Yesterday</span>
            <span className="positive">
              ↗ 4.2%
            </span>
          </div>
        </div>

        <div className="stats-card">
          <div className="stats-value">
            1,631
          </div>

          <div className="stats-title">
            Visitors Inside
          </div>

          <div className="stats-footer">
            <span>Last hour</span>
            <span className="negative">
              ↙ 6.5%
            </span>
          </div>
        </div>

        <div className="stats-card">
          <div className="stats-value">
            12:30
          </div>

          <div className="stats-title">
            Peak Hour
          </div>

          <div className="stats-footer">
            <span>1,091 Visitors</span>
          </div>
        </div>
        <div className="stats-card">
          <div className="stats-value">
            29min
          </div>

          <div className="stats-title">
           Avg Dwell Time
          </div>

          <div className="stats-footer">
            <span>Yesterday</span>
          </div>
        </div>
        <div className="stats-card">
          <div className="stats-value">
            3
          </div>

          <div className="stats-title">
         Active Alert
          </div>

          <div className="stats-footer">
            <span>1 New Alert</span>
          </div>
        </div>

      </div>

      {/* RIGHT */}

      <div className="right-panel">

        <div className="heatmap-card">

          {/* TOPBAR */}

          <div className="heatmap-topbar">

            <div className="breadcrumb">

              <span>
                🏢 {selectedMall.mallName}
              </span>

              <span>
                🏬 {selectedFloor.floorName}
              </span>

            </div>

            <button
              className="fullscreen-btn"
              onClick={() => setIsFullscreen(true)}
            >
              ⛶
            </button>

          </div>

          {/* LEGEND */}

          <div className="legend-section">

            <span className="legend-label">
              Occupancy
            </span>

            <div className="legend-bar" />

            <div className="legend-range">
              <span>0%</span>
              <span>100%</span>
            </div>

          </div>

          {/* MAP AREA */}

          <div className="map-wrapper">

            {/* ONLY IMAGE SCROLLS */}

            <div className="map-scroll">

              <div
                ref={mapRef}
                className="map-inner"
                style={{
                  width: renderWidth,
                  height: renderHeight,
                }}
              >

                <img
                  src={selectedFloor.floorImage}
                  alt=""
                  className="floor-image"
                />

                {selectedFloor.zones.map(
                  (zone) => {

                    const centerX =
                      zone.points.reduce(
                        (sum, p) =>
                          sum + p.x,
                        0
                      ) /
                      zone.points.length;

                    const centerY =
                      zone.points.reduce(
                        (sum, p) =>
                          sum + p.y,
                        0
                      ) /
                      zone.points.length;

                    const mappedX =
                      centerX * zoom;

                    const mappedY =
                      centerY * zoom;

                    const occupancy =
                      Math.max(
                        0,
                        Math.min(
                          100,
                          zone.occupancy +
                          (timelineHour -
                            14) *
                          2
                        )
                      );

                    const heatSize =
                      occupancy >= 90
                        ? 420
                        : occupancy >= 70
                          ? 350
                          : occupancy >= 50
                            ? 280
                            : 220;

                    return (
                      <React.Fragment
                        key={zone.zoneId}
                      >

                        <div
                          className={`heat-glow ${gradientType}`}
                          style={{
                            width: heatSize,
                            height: heatSize,
                            left: mappedX,
                            top: mappedY,
                            opacity:
                              occupancy / 100,
                          }}
                        />

                        <div
                          className="zone-label"
                          style={{
                            left: mappedX,
                            top: mappedY,
                          }}
                        >

                          <h4>
                            {zone.zoneName}
                          </h4>

                          <p>
                            {occupancy}%
                          </p>

                        </div>

                      </React.Fragment>
                    );
                  }
                )}

              </div>

            </div>

            {/* FIXED CONTROLS */}

            <div className="map-tools">

              <button
                onClick={() =>
                  setZoom(
                    (prev) => prev + 0.1
                  )
                }
              >
                +
              </button>

              <button
                onClick={() =>
                  setZoom((prev) =>
                    Math.max(
                      0.4,
                      prev - 0.1
                    )
                  )
                }
              >
                −
              </button>

              <div
                className="gradient-tool first"
                onClick={() =>
                  setGradientType(
                    "default"
                  )
                }
              />

              <div
                className="gradient-tool second"
                onClick={() =>
                  setGradientType(
                    "purple"
                  )
                }
              />

            </div>

            {/* FIXED TIMELINE */}

            <div className="timeline-container">

              <input
                type="range"
                min="9"
                max="19"
                value={timelineHour}
                onChange={(e) =>
                  setTimelineHour(
                    Number(
                      e.target.value
                    )
                  )
                }
              />

              <div className="timeline-hours">

                {hours.map((hour) => (
                  <span key={hour}>
                    {hour}
                  </span>
                ))}

              </div>

            </div>

          </div>
        </div>
      </div>

      {/* FULLSCREEN MODAL */}

      {isFullscreen && (
        <div className="fullscreen-overlay">

          <div className="fullscreen-header">

            <h3>
              {selectedMall.mallName} -{" "}
              {selectedFloor.floorName}
            </h3>

            <button
              className="close-btn"
              onClick={() =>
                setIsFullscreen(false)
              }
            >
              ✕
            </button>

          </div>

          <div className="fullscreen-map-scroll">

            <div
              className="fullscreen-map-inner"
              style={{
                width: renderWidth,
                height: renderHeight,
              }}
            >

              <img
                src={selectedFloor.floorImage}
                alt=""
                className="floor-image"
              />

              {selectedFloor.zones.map((zone) => {

                const centerX =
                  zone.points.reduce(
                    (sum, p) => sum + p.x,
                    0
                  ) / zone.points.length;

                const centerY =
                  zone.points.reduce(
                    (sum, p) => sum + p.y,
                    0
                  ) / zone.points.length;

                const mappedX = centerX * zoom;
                const mappedY = centerY * zoom;

                return (
                  <React.Fragment
                    key={zone.zoneId}
                  >

                    <div
                      className={`heat-glow ${gradientType}`}
                      style={{
                        left: mappedX,
                        top: mappedY,
                        width: 380,
                        height: 380,
                      }}
                    />

                    <div
                      className="zone-label"
                      style={{
                        left: mappedX,
                        top: mappedY,
                      }}
                    >
                      <h4>{zone.zoneName}</h4>
                      <p>{zone.occupancy}%</p>
                    </div>

                  </React.Fragment>
                );
              })}
            </div>
          </div>

          {/* FIXED TOOLS */}

          <div className="fullscreen-tools">

            <button
              onClick={() =>
                setZoom((prev) => prev + 0.1)
              }
            >
              +
            </button>

            <button
              onClick={() =>
                setZoom((prev) =>
                  Math.max(0.4, prev - 0.1)
                )
              }
            >
              −
            </button>

          </div>

          {/* TIMELINE */}

          <div className="fullscreen-timeline">

            <input
              type="range"
              min="9"
              max="19"
              value={timelineHour}
              onChange={(e) =>
                setTimelineHour(
                  Number(e.target.value)
                )
              }
            />

            <div className="timeline-hours">
              {hours.map((hour) => (
                <span key={hour}>
                  {hour}
                </span>
              ))}
            </div>

          </div>
        </div>
      )}
    </div>
  );
}