import React from 'react'

const MapwiseTab = () => {
  return (
    <div>MapwiseTab</div>
  )
}

export default MapwiseTab