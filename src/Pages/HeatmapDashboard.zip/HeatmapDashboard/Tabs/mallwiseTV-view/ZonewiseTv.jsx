import React, { useEffect, useRef, useState } from "react";
import dayjs from "dayjs";
import "../../Styles/mallwiseTV.css";
// import HeatmapCanvasTV from "../../CommonComponents/HeatmapCanvasTV";
import HeatmapLegend from "../../CommonComponents/HeatmapLegend";
import {
  getDashboardWidgets,
  getHeatmapFilter1,
  getHeatmapMallandZoneDashboard,
} from "../../api/HeatmapDashboardApis";
// import useHeatmap from "../../hooks/useHeatmap";
import TVSidebar from "./TVSidebar";
import TVFooter from "./TVFooter";
import { FiMapPin, FiShoppingBag, FiLayers } from "react-icons/fi";
import Select from "react-select";
import "../../Styles/LoaderOverlay.css";
import { Spinner } from "react-bootstrap";
import OccupancyOverview from "./Overview";
import ZoneHeatmapCanvasTV from "../../CommonComponents/ZoneHeatmapCanvasTV";
// ZoneHeatmapCanvasTV
const ZonewiseTV = () => {
  // ==========================================
  // Component State Management
  // ==========================================

  const [loading, setLoading] = useState(false);
  const [dashboardData, setDashboardData] = useState([]);
  const [selectedMall, setSelectedMall] = useState(null);
  const [selectedFloor, setSelectedFloor] = useState(null);
  const [selectedZone, setSelectedZone] = useState(null);
  const [cards, setCards] = useState({
    widget1: {},
    widget2: {},
    widget3: {},
    widget4: {},
  });

  const [widgetPayload, setWidgetPayload] = useState(null);
  const [dashboardPayload, setDashboardPayload] = useState(null);
  const [filtersLoaded, setFiltersLoaded] = useState(false);
  const [filterData, setFilterData] = useState([]);
  const username = sessionStorage.getItem("username");
  const token = sessionStorage.getItem("token");
  const vid = sessionStorage.getItem("vid");

  // console.log(username);

  const selectedMallRef = useRef(null);
  const selectedFloorRef = useRef(null);
  const selectedZoneRef = useRef(null);
  const dashboardDataRef = useRef([]);

  const autoRotateRef = useRef({
    mallIndex: 0,
    floorIndex: 0,
    zoneIndex: 0,
  });
  // ==========================================
  // Load Filter Data and Prepare Request Payloads
  // ==========================================

  const loadFilters = async () => {
    try {
      const res = await getHeatmapFilter1(username);
      const responseData = res?.savedFilter || [];
      if (!responseData.length) return;

      // Dropdown Data

      setFilterData(responseData);
      setSelectedMall(responseData[0]);
      setSelectedFloor(responseData[0].floors[0]);
      setSelectedZone(
        responseData[0].floors[0]?.zones?.[0] || null
      );

      // Widget Payload
      setWidgetPayload({
        mallname: responseData.map((m) => m.mallName).join(","),
        floorname: responseData
          .flatMap((m) => m.floors)
          .map((f) => f.floorName)
          .join(","),
        zonename: responseData
          .flatMap((m) => m.floors)
          .flatMap((f) => f.zones)
          .map((z) => z.zoneName)
          .join(","),
        inputDate: dayjs().format("YYYY-MM-DD"),
      });

      // Dashboard Payload
      setDashboardPayload({
        inputDate: dayjs().format("YYYY-MM-DD"),
        filters: responseData.flatMap((m) =>
          m.floors.flatMap((f) =>
            f.zones.map((z) => ({
              mallName: m.mallName,
              floorName: f.floorName,
              zoneName: z.zoneName,
            })),
          ),
        ),
      });

      setFiltersLoaded(true);
    } catch (err) {
      console.log(err);
    }
  };

  // ==========================================
  // Load Dashboard Widgets and Heatmap Data
  // ==========================================

  const loadDashboard = async (showLoader = true) => {
    try {
      if (!widgetPayload || !dashboardPayload) return;

      if (showLoader) {
        setLoading(true);
      }

      const [widgets, dashboard] = await Promise.all([
        getDashboardWidgets(widgetPayload),
        getHeatmapMallandZoneDashboard(dashboardPayload),
      ]);

      const malls = (dashboard.malls || []).map((mall) => ({
        ...mall,
        floors: mall.floors.map((floor) => ({
          ...floor,
          zones: floor.zones.map((zone) => ({
            ...zone,
            points: zone.points?.points || [],
          })),
        })),
      }));

      setDashboardData(malls);
      setCards(widgets);
      dashboardDataRef.current = malls;
      // Preserve selected mall/floor

      const currentMall =
        malls.find((m) => m.mallId === selectedMallRef.current?.mallId) || malls[0];

      setSelectedMall(currentMall);

      const currentFloor =
        currentMall?.floors.find(
          (f) => f.floorId === selectedFloorRef.current?.floorId
        ) || currentMall?.floors?.[0];

      setSelectedFloor(currentFloor);

      // Preserve current selected zone after dashboard refresh
      const currentZone =
        currentFloor?.zones.find(
          (z) => z.zoneId === selectedZoneRef.current?.zoneId
        ) || currentFloor?.zones?.[0];

      setSelectedZone(currentZone);

      const currentMallIndex = malls.findIndex(
        (m) => m.mallId === currentMall?.mallId,
      );

      const currentFloorIndex = currentMall?.floors.findIndex(
        (f) => f.floorId === currentFloor?.floorId,
      );

      const currentZoneIndex =
        currentFloor?.zones.findIndex(
          (z) => z.zoneId === currentZone?.zoneId
        ) ?? 0;
      
      autoRotateRef.current = {
        mallIndex: Math.max(0, currentMallIndex),
        floorIndex: Math.max(0, currentFloorIndex),
        zoneIndex: Math.max(0, currentZoneIndex),
        };
    } catch (err) {
      console.log(err);
    } finally {
      if (showLoader) {
        setLoading(false);
      }
    }
  };
  // ==========================================
  // Load Filter Data on Component Mount
  // ==========================================

  useEffect(() => {
    loadFilters();
  }, []);

  useEffect(() => {
    selectedMallRef.current = selectedMall;
  }, [selectedMall]);

  useEffect(() => {
    selectedFloorRef.current = selectedFloor;
  }, [selectedFloor]);
  useEffect(() => {
    selectedZoneRef.current = selectedZone;
  }, [selectedZone]);
  // // ==========================================
  // // Auto Refresh Dashboard Every 15 Seconds
  // // ==========================================

  // useEffect(() => {
  //   if (!filtersLoaded) return;

  //   // Initial Load (show loader)
  //   loadDashboard(true);

  //   const interval = setInterval(() => {
  //     // Background refresh (no loader)
  //     loadDashboard(false);
  //   }, 15000);

  //   return () => clearInterval(interval);
  // }, [filtersLoaded]);

  // ==========================================
  // Auto Rotate the floors Every 30 Seconds
  // ==========================================
  // useEffect(() => {
  //   if (!filtersLoaded) return;

  //   const interval = setInterval(() => {
  //     const malls = dashboardDataRef.current;

  //     if (!malls.length) return;

  //     const currentMall = selectedMallRef.current;
  //     const currentFloor = selectedFloorRef.current;

  //     if (!currentMall || !currentFloor) return;

  //     const mallIndex = malls.findIndex((m) => m.mallId === currentMall.mallId);

  //     if (mallIndex === -1) return;

  //     const mall = malls[mallIndex];

  //     const floorIndex = mall.floors.findIndex(
  //       (f) => f.floorId === currentFloor.floorId,
  //     );

  //     let nextMall = mall;
  //     let nextFloor = null;

  //     // Next floor in same mall
  //     if (floorIndex < mall.floors.length - 1) {
  //       nextFloor = mall.floors[floorIndex + 1];
  //     } else {
  //       // Move to next mall
  //       const nextMallIndex =
  //         mallIndex === malls.length - 1 ? 0 : mallIndex + 1;

  //       nextMall = malls[nextMallIndex];
  //       nextFloor = nextMall.floors[0];
  //     }

  //     setSelectedMall(nextMall);
  //     setSelectedFloor(nextFloor);
  //   }, 30000);

  //   return () => clearInterval(interval);
  // }, [filtersLoaded]);

  useEffect(() => {
    if (!filtersLoaded) return;

    // Initial load
    loadDashboard(true);

    const interval = setInterval(async () => {
      const malls = dashboardDataRef.current;

      if (!malls.length) return;

      let { mallIndex, floorIndex, zoneIndex } = autoRotateRef.current;

      const mall = malls[mallIndex];
      if (!mall) return;

      const floor = mall.floors[floorIndex];
      if (!floor) return;

      // -------------------------
      // Next Zone
      // -------------------------
      if (zoneIndex < floor.zones.length - 1) {
        zoneIndex++;
      } else {
        zoneIndex = 0;

        // -------------------------
        // Next Floor
        // -------------------------
        if (floorIndex < mall.floors.length - 1) {
          floorIndex++;
        } else {
          floorIndex = 0;

          // -------------------------
          // Next Mall
          // -------------------------
          if (mallIndex < malls.length - 1) {
            mallIndex++;
          } else {
            mallIndex = 0;
          }
        }
      }

      const nextMall = malls[mallIndex];
      const nextFloor = nextMall.floors[floorIndex];
      const nextZone = nextFloor.zones[zoneIndex];

      setSelectedMall(nextMall);
      setSelectedFloor(nextFloor);
      setSelectedZone(nextZone);

      // Keep refs in sync immediately
      selectedMallRef.current = nextMall;
      selectedFloorRef.current = nextFloor;
      selectedZoneRef.current = nextZone;

      autoRotateRef.current = {
        mallIndex,
        floorIndex,
        zoneIndex,
      };

      await loadDashboard(false);
    }, 15000);

    return () => clearInterval(interval);
  }, [filtersLoaded, widgetPayload, dashboardPayload]);
  // ==========================================
  // Get Selected Mall and Floor from Dashboard Data
  // ==========================================

  const dashboardMall = dashboardData.find(
    (m) => m.mallId === selectedMall?.mallId,
  );

  const dashboardFloor = dashboardMall?.floors.find(
    (f) => f.floorId === selectedFloor?.floorId,
  );

  // // ==========================================
  // // Prepare Heatmap Data for Rendering
  // // ==========================================

  // const { zonesToRender } = useHeatmap({
  //   mode: "tv",
  //   selectedFloor: dashboardFloor,
  // });

  // ==========================================
  // Extract Widget Data for Sidebar Cards
  // ==========================================

  const widget1 = cards?.widget1?.data?.[0] || {};
  const widget2 = cards?.widget2?.data?.[0] || {};
  const widget3 = cards?.widget3?.data?.[0] || {};
  const widget4 = cards?.widget4?.data?.[0] || {};

  // ==========================================
  //  Data for Mall Dropdown Options
  // ==========================================

  const mallOptions = dashboardData.map((mall) => ({
    value: mall.mallId,
    label: mall.mallName,
  }));

  // ==========================================
  // Data for Floor Dropdown Options
  // ==========================================

  const floorOptions =
    dashboardMall?.floors.map((floor) => ({
      value: floor.floorId,
      label: floor.floorName,
    })) || [];
  
  // ==========================================
  // Data for zone Dropdown Options
    // ==========================================
  const zoneOptions =
    dashboardFloor?.zones.map(zone => ({
      value: zone.zoneId,
      label: zone.zoneName
    })) || [];
  
  return (
    <div className="tv-page">
      {/*==========================================
                 Header Section
        ========================================== */}

      <div className="tv-header">
        <div className="tv-header-left">
          <h2>Heatmap Dashboard - Zonewise</h2>
        </div>
        {loading && (
          <div className="loader-overlay">
            <Spinner animation="border" variant="primary" />
            <p>Loading...</p>
          </div>
        )}
        <div className="tv-header-right">
          {/* Mall */}

          <div className="filter-group-horizontal">
            <label className="filter-inline-label">Mall :</label>

            <div className="tv-filter-card">
              <div className="tv-select-box">
                <FiShoppingBag className="tv-icon" />
                <Select
                  className="tv-react-select"
                  classNamePrefix="tv-select"
                  isSearchable={false}
                  options={mallOptions}
                  value={
                    mallOptions.find((m) => m.value === selectedMall?.mallId) ||
                    null
                  }
      
                  onChange={(option) => {
                    const mallIndex = dashboardData.findIndex(
                      (m) => m.mallId === option.value,
                    );

                    if (mallIndex === -1) return;

                    const mall = dashboardData[mallIndex];

                    setSelectedMall(mall);
                    setSelectedFloor(mall.floors?.[0] || null);
                    setSelectedZone(
                      mall.floors?.[0]?.zones?.[0] || null
                  );
                    autoRotateRef.current = {
                      mallIndex,
                      floorIndex: 0,
                      zoneIndex: 0
                };
                  }}
                />
              </div>
            </div>
          </div>

          {/* Floor */}
          <div className="filter-group-horizontal">
            <label className="filter-inline-label">Floor :</label>

            <div className="tv-filter-card">
              <div className="tv-select-box">
                <FiLayers className="tv-icon" />
                <Select
                  className="tv-react-select"
                  classNamePrefix="tv-select"
                  isSearchable={false}
                  options={floorOptions}
                  value={
                    floorOptions.find(
                      (f) => f.value === selectedFloor?.floorId,
                    ) || null
                  }
                  onChange={(option) => {
                    const floorIndex = dashboardMall?.floors.findIndex(
                      (f) => f.floorId === option.value,
                    );

                    if (floorIndex === -1) return;

                    const floor = dashboardMall.floors[floorIndex];

                    setSelectedFloor(floor);
                    setSelectedZone(
                      floor.zones?.[0] || null
                  );
                    autoRotateRef.current = {
                      mallIndex: autoRotateRef.current.mallIndex,
                      floorIndex,
                      zoneIndex: 0
                };
                  }}
                />
              </div>
            </div>
          </div>
          {/*Zone */}
          <div className="filter-group-horizontal">
            <label className="filter-inline-label">
              Zone :
            </label>

            <div className="tv-filter-card">
              <div className="tv-select-box">

                <FiMapPin className="tv-icon" />

                <Select
                  className="tv-react-select"
                  classNamePrefix="tv-select"
                  isSearchable={false}
                  options={zoneOptions}
                  value={
                    zoneOptions.find(
                      z => z.value === selectedZone?.zoneId
                    ) || null
                  }
                  onChange={(option) => {

                    const zone =
                      dashboardFloor?.zones.find(
                        z => z.zoneId === option.value
                      );

                    if (zone) {

                      setSelectedZone(zone);
                      const zoneIndex = dashboardFloor.zones.findIndex(
                        z => z.zoneId === zone.zoneId
                      );

                      autoRotateRef.current = {
                        ...autoRotateRef.current,
                        zoneIndex
                    };

                    }

                  }}
                />

              </div>
            </div>
          </div>
        </div>
      </div>

      {/* ==========================================
                  Sidebar Widgets
        ========================================== */}

      <div className="tv-content">
        <TVSidebar widget2={widget2} widget3={widget3} widget4={widget4} />

        {/* ==========================================
                  Heatmap Canvas
           ========================================== */}

        <div className="tv-map-container">
          {dashboardFloor && (
            <ZoneHeatmapCanvasTV
              selectedFloor={dashboardFloor}
              selectedZone={selectedZone}
     />
          )}
          {/* <HeatmapBottomLegend /> */}
        </div>
        <OccupancyOverview
          // occupancy={occupancy}
          // inside={inside}
          selectedMall={selectedMall}
          selectedFloor={selectedFloor}
          capacity={822}
        />
      </div>

      {/* ==========================================
               Footer Section
          ========================================== */}
      <TVFooter
        rotationText="🟢 LIVE | 🔄 15s Zone Rotation & Data Refresh"
      />
    </div>
  );
};

export default ZonewiseTV;
