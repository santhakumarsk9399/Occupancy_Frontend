// import React, { useState } from 'react'
// import DashHeader from '../CommonComponents/Dashboard_Header';
// import { Tab, Nav, Spinner } from "react-bootstrap";

// const HeatmapDashboard = () => {
//   const [activeTab, setActiveTab] = useState("Live");
//     const [pageLoading, setPageLoading] = useState(true);
//   return (
//     <div className="Dashcontainer">
//       <DashHeader
//         title="Heatmap-Overview"
//         onFilterClick={async () => {
//           await filters();
//           setShowFilters(true);
//         }}
//       />

//       <div className="tabsec_dash">
//         <Tab.Container
//           activeKey={activeTab}
//           onSelect={(k) => setActiveTab(k || "Live")}
//         >
//           <Nav variant="tabs">
//             <Nav.Item>
//               <Nav.Link eventKey="Live">Live</Nav.Link>
//             </Nav.Item>
//             <Nav.Item>
//               <Nav.Link eventKey="Mall">Mall-wise</Nav.Link>
//             </Nav.Item>
//             <Nav.Item>
//               <Nav.Link eventKey="Zone">Zone-wise</Nav.Link>
//             </Nav.Item>
//             <Nav.Item>
//               <Nav.Link eventKey="Map">Map-wise</Nav.Link>
//             </Nav.Item>
//           </Nav>

//           <Tab.Content className="bg-white border p-3">
//             <Tab.Pane eventKey="Live">
//               <div className="Dash_TopSection">
//                 <div className="Dash_Section">
//                   <div>
//                     {/* <div className="mt-1">
//                       {pageLoading ? (
//                         <div
//                           style={{
//                             display: "flex",
//                             flexDirection: "column",
//                             justifyContent: "center",
//                             alignItems: "center",
//                             height: "90vh",
//                             // background: "rgba(250,250,250,0.7)",
//                             borderRadius: "12px",
//                           }}
//                         >
//                           <Spinner
//                             animation="border"
//                             variant="primary"
//                             style={{ width: "2rem", height: "2rem" }}
//                           />
//                           <p className="mt-3 text-muted">Loading chart...</p>
//                         </div>
//                       ) : dashboardData && dashboardData.length > 0 ? (
//                         <CustomCard
//                           title=""
//                           size="md"
//                           style={{ background: "white", padding: "10px" }}
//                         >
//                           <LiveOccupancyChart2 data={dashboardData} />
//                         </CustomCard>
//                       ) : (
//                         <div className="dash3NodataDiv">
//                           {" "}
//                           <NoData name="no-data-container" />
//                         </div>
//                       )}
//                     </div> */}
//                   </div>
//                 </div>
//               </div>
//             </Tab.Pane>
//           </Tab.Content>

//           <Tab.Content className="bg-white border p-3">
//             <Tab.Pane eventKey="Mall">
//               {/* <Dashboard2 zones={zones} isActive={activeTab === "Mall"} /> */}
//             </Tab.Pane>
//           </Tab.Content>

//           <Tab.Content className="bg-white border p-3">
//             <Tab.Pane eventKey="Zone">
//               {/* <Dashboard3 zones={zones} isActive={activeTab === "Zone"} /> */}
//             </Tab.Pane>
//           </Tab.Content>

//           <Tab.Content className="bg-white border p-3">
//             <Tab.Pane eventKey="Map">
//               {/* <Dashboard3 zones={zones} isActive={activeTab === "Map"} /> */}
//             </Tab.Pane>
//           </Tab.Content>
//         </Tab.Container>
//       </div>
//     </div>
//   )
// }

// export default HeatmapDashboard

import React, { useState } from "react";
import DashHeader from "../CommonComponents/Dashboard_Header";
import { Tab, Nav, Spinner } from "react-bootstrap";
import LiveTab from "./Tabs/LiveTab";
import MallwiseTab from "./Tabs/MallwiseTab";
import ZonewiseTab from "./Tabs/ZonewiseTab";
import MapwiseTab from "./Tabs/MapwiseTab";

const HeatmapDashboard = () => {
  const [activeTab, setActiveTab] = useState("Live");
  const [pageLoading, setPageLoading] = useState(false);

  return (
    <div className="Dashcontainer heatmap-scroll">
      <DashHeader
        title="Heatmap - Overview"
        onFilterClick={async () => {
          // your filter logic
        }}
      />

      <div className="tabsec_dash">
        <Tab.Container
          activeKey={activeTab}
          onSelect={(k) => setActiveTab(k || "Live")}
        >
          {/* Tabs */}
          <Nav variant="tabs">
            <Nav.Item>
              <Nav.Link eventKey="Live">Live</Nav.Link>
            </Nav.Item>
            <Nav.Item>
              <Nav.Link eventKey="Mall">Mall-wise</Nav.Link>
            </Nav.Item>
            <Nav.Item>
              <Nav.Link eventKey="Zone">Zone-wise</Nav.Link>
            </Nav.Item>
            <Nav.Item>
              <Nav.Link eventKey="Map">Map-wise</Nav.Link>
            </Nav.Item>
          </Nav>

          {/* ✅ SINGLE Tab.Content */}
          <Tab.Content className="p-3">

            <Tab.Pane eventKey="Live">
              {pageLoading ? (
                <div className="loader-center">
                  <Spinner animation="border" />
                </div>
              ) : (
                <LiveTab />
              )}
            </Tab.Pane>

            <Tab.Pane eventKey="Mall">
              <MallwiseTab />
            </Tab.Pane>

            <Tab.Pane eventKey="Zone">
              <ZonewiseTab />
            </Tab.Pane>

            <Tab.Pane eventKey="Map">
              <MapwiseTab />
            </Tab.Pane>

          </Tab.Content>
        </Tab.Container>
      </div>
    </div>
  );
};

export default HeatmapDashboard;