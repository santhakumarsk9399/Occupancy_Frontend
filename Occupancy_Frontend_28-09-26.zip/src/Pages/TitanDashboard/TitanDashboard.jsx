import React, { useEffect, useState, useCallback, memo } from "react";

import {
    PieChart,
    Pie,
    Cell,
    ResponsiveContainer,
    BarChart,
    Bar,
    XAxis,
    YAxis,
    CartesianGrid,
    LabelList,
    Tooltip,
} from "recharts";

import {
    Building2,
    UsersRound,
    UserRoundPlus,
    UserRound,
    Gauge,
    CalendarDays,
    Clock3,
} from "lucide-react";

import "./TitanDashboard.css";

import titanLogo2 from "../../Components/Assets/Titan/titan-logo2.avif";
import titanLogo from "../../Components/Assets/Titan/titan-logo.png";
import factoryImage5 from "../../Components/Assets/Titan/factory-image5.png";
import footerlogo from "../../Components/Assets/footer-logo.svg";

import axios from "axios";

/* =========================================================
   DISTRIBUTION COLORS
========================================================= */

const distributionColors = [
    "#6652D9",
    "#9A65D6",
    "#FFB23E",
    "#20BFAF",
    "#FF7959",
];

/* =========================================================
   DONUT TOOLTIP
========================================================= */

const DonutTooltip = ({ active, payload }) => {
    if (!active || !payload?.length) {
        return null;
    }

    const item = payload[0]?.payload || {};

    const value = Number(item?.value || 0);

    const percentage =
        item?.percentage !== undefined && item?.percentage !== null
            ? String(item.percentage).replace("%", "")
            : "";

    return (
        <div className="titan-donut-tooltip">
            <div className="titan-tooltip-title">{item?.zone || "Location"}</div>

            <div className="titan-tooltip-row">
                <span>Occupancy</span>

                <strong>{value}</strong>
            </div>

            <div className="titan-tooltip-row">
                <span>Share</span>

                <strong>{percentage}%</strong>
            </div>
        </div>
    );
};

/* =========================================================
   LOCATION TOOLTIP
========================================================= */

const LocationTooltip = ({ active, payload, label }) => {
    if (!active || !payload?.length) {
        return null;
    }

    const gents = Number(
        payload.find((item) => item.dataKey === "gents")?.value || 0,
    );

    const ladies = Number(
        payload.find((item) => item.dataKey === "ladies")?.value || 0,
    );

    const total = gents + ladies;

    return (
        <div className="titan-chart-tooltip">
            <div className="titan-tooltip-title">{label || "Location"}</div>

            <div className="titan-tooltip-row">
                <span>
                    <i className="titan-tooltip-dot titan-tooltip-gents" />
                    Gents
                </span>

                <strong>{gents}</strong>
            </div>

            <div className="titan-tooltip-row">
                <span>
                    <i className="titan-tooltip-dot titan-tooltip-ladies" />
                    Ladies
                </span>

                <strong>{ladies}</strong>
            </div>

            <div className="titan-tooltip-total">
                Total
                <strong>{total}</strong>
            </div>
        </div>
    );
};

/* =========================================================
   NO DATA COMPONENT
========================================================= */

const NoDataAvailable = ({ message = "Data is not available." }) => {
    return (
        <div className="titan-no-data" role="status" aria-label="No data available">
            <div className="titan-no-data-icon">
                <Building2 size={30} strokeWidth={1.5} />
            </div>

            <strong>No Data Available</strong>

            <span>{message}</span>
        </div>
    );
};

/* =========================================================
   DASHBOARD CONTENT
========================================================= */

const TitanDashboardData = memo(function TitanDashboardData({ data }) {
    /* =====================================================
             SAFE DATA EXTRACTION
          ===================================================== */

    const topCards = data?.topcards || data?.topCards || {};

    const occupancyDistribution =
        data?.occupancyDistribution || {};

    const rawDistributionData = Array.isArray(
        occupancyDistribution?.data
    )
        ? occupancyDistribution.data
        : [];

    // Normalize API field names:
    // API returns "Zone", while the charts use "zone".
    const distributionData = rawDistributionData.map((item) => ({
        ...item,
        zone: item?.Zone ?? item?.zone ?? "",
        value: Number(item?.value ?? 0),
    }));

    const rawOccupancyByLocation = Array.isArray(
        data?.occupancyByLocation
    )
        ? data.occupancyByLocation
        : [];

    // Normalize zone/gents/ladies values for the stacked bar chart.
    const occupancyByLocation = rawOccupancyByLocation.map((item) => ({
        ...item,
        zone: item?.Zone ?? item?.zone ?? "",
        gents: Number(item?.gents ?? 0),
        ladies: Number(item?.ladies ?? 0),
        total: Number(
            item?.value ??
            Number(item?.gents ?? 0) + Number(item?.ladies ?? 0)
        ),
    }));

    const bottomCards = data?.bottomCards || {};

    /* =====================================================
             TOTAL OCCUPANTS
          ===================================================== */

    const totalOccupants = Number(
        occupancyDistribution?.totalOccupants ?? bottomCards?.totalOccupants ?? 0,
    );

    /* =====================================================
             PERCENTAGE
          ===================================================== */

    const getPercentage = (value) => {
        if (!totalOccupants) {
            return 0;
        }

        return Math.round((Number(value || 0) / totalOccupants) * 100);
    };

    /* =====================================================
             DONUT DATA
          ===================================================== */

    const distributionChartData = distributionData.map((item) => ({
        ...item,

        percentage:
            item?.percentage !== undefined && item?.percentage !== null
                ? String(item.percentage).includes("%")
                    ? String(item.percentage)
                    : `${item.percentage}%`
                : `${getPercentage(item?.value)}%`,
    }));

    /* =====================================================
             OVERALL OCCUPANCY
          ===================================================== */

    const occupancy = Math.max(
        0,
        Math.min(100, Number(bottomCards?.overallOccupancy || 0)),
    );

    return (
        <>
            {/* =================================================
                    KPI CARDS
                ================================================= */}

            <section className="titan-kpi-grid">
                {/* New Building */}

                <div className="titan-kpi-card titan-kpi-new">
                    <div className="titan-kpi-icon">
                        <Building2 size={25} strokeWidth={1.7} />
                    </div>

                    <div className="titan-kpi-info">
                        <span className="titan-kpi-label">New Building</span>

                        <strong className="titan-kpi-value">
                            {topCards.newBuilding ?? 0}
                        </strong>

                        <span className="titan-kpi-status">Current occupancy</span>
                    </div>
                </div>

                {/* Old Building */}

                <div className="titan-kpi-card titan-kpi-old">
                    <div className="titan-kpi-icon">
                        <Building2 size={25} strokeWidth={1.7} />
                    </div>

                    <div className="titan-kpi-info">
                        <span className="titan-kpi-label">Old Building</span>

                        <strong className="titan-kpi-value">
                            {topCards.oldBuilding ?? 0}
                        </strong>

                        <span className="titan-kpi-status">Current occupancy</span>
                    </div>
                </div>

                {/* CBC */}

                <div className="titan-kpi-card titan-kpi-cbc">
                    <div className="titan-kpi-icon">
                        <Building2 size={25} strokeWidth={1.7} />
                    </div>

                    <div className="titan-kpi-info">
                        <span className="titan-kpi-label">CBC</span>

                        <strong className="titan-kpi-value">{topCards.cbc ?? 0}</strong>

                        <span className="titan-kpi-status">Current occupancy</span>
                    </div>
                </div>

                {/* Warehouse */}

                <div className="titan-kpi-card titan-kpi-warehouse">
                    <div className="titan-kpi-icon">
                        <Building2 size={25} strokeWidth={1.7} />
                    </div>

                    <div className="titan-kpi-info">
                        <span className="titan-kpi-label">Warehouse</span>

                        <strong className="titan-kpi-value">
                            {topCards.warehouse ?? 0}
                        </strong>

                        <span className="titan-kpi-status">Current occupancy</span>
                    </div>
                </div>
            </section>

            {/* =================================================
                    MAIN ANALYTICS GRID
                ================================================= */}

            <section className="titan-main-grid">
                {/* =================================================
                        LEFT COLUMN
                    ================================================= */}

                <div className="titan-left-column">
                    {/* =================================================
                            OCCUPANCY DISTRIBUTION
                        ================================================= */}

                    <div className="titan-chart-card titan-distribution-card">
                        <div className="titan-chart-heading">
                            <div>
                                <h2>Occupancy Distribution</h2>

                                <p>Current occupancy distribution by location</p>
                            </div>
                        </div>

                        <div className="titan-distribution-body">
                            {/* =================================================
                                    DONUT DATA AVAILABLE
                                ================================================= */}

                            {distributionData.length > 0 ? (
                                <>
                                    {/* <div className="titan-donut-wrapper">
                                        <ResponsiveContainer width="100%" height="100%">
                                            <PieChart>
                                                <Tooltip
                                                    content={<DonutTooltip />}
                                                    cursor={false}
                                                    offset={15}
                                                    wrapperStyle={{
                                                        outline: "none",
                                                        zIndex: 1000,
                                                        pointerEvents: "none",
                                                    }}
                                                />

                                                <Pie
                                                    data={distributionChartData}
                                                    dataKey="value"
                                                    nameKey="zone"
                                                    cx="50%"
                                                    cy="50%"
                                                    innerRadius="42%"
                                                    outerRadius="78%"
                                                    paddingAngle={0}
                                                    stroke="#ffffff"
                                                    strokeWidth={4}
                                                    labelLine={false}
                                                    label={({
                                                        cx,
                                                        cy,
                                                        midAngle,
                                                        innerRadius,
                                                        outerRadius,
                                                        index,
                                                    }) => {
                                                        const RADIAN = Math.PI / 180;

                                                        const radius =
                                                            innerRadius + (outerRadius - innerRadius) * 0.5;

                                                        const x =
                                                            cx + radius * Math.cos(-midAngle * RADIAN);

                                                        const y =
                                                            cy + radius * Math.sin(-midAngle * RADIAN);

                                                        const item = distributionChartData[index];

                                                        return (
                                                            <text
                                                                x={x}
                                                                y={y}
                                                                fill="#ffffff"
                                                                textAnchor="middle"
                                                                dominantBaseline="central"
                                                                fontSize={16}
                                                                fontWeight={700}
                                                            >
                                                                {item?.percentage}
                                                            </text>
                                                        );
                                                    }}
                                                >
                                                    {distributionChartData.map((item, index) => (
                                                        <Cell
                                                            key={`distribution-${index}`}
                                                            fill={
                                                                distributionColors[
                                                                index % distributionColors.length
                                                                ]
                                                            }
                                                        />
                                                    ))}
                                                </Pie>
                                            </PieChart>
                                        </ResponsiveContainer>

                                        <div className="titan-donut-center">
                                            <strong>{totalOccupants}</strong>

                                            <span>Total Occupancy</span>
                                        </div>
                                    </div> */}
                                    <div className="titan-donut-wrapper">
                                        <ResponsiveContainer width="100%" height="100%">
                                            <PieChart>

                                                <Tooltip
                                                    content={<DonutTooltip />}
                                                    cursor={false}
                                                    offset={15}
                                                    wrapperStyle={{
                                                        outline: "none",
                                                        zIndex: 1000,
                                                        pointerEvents: "none",
                                                    }}
                                                />

                                                <Pie
                                                    data={distributionChartData}
                                                    dataKey="value"
                                                    nameKey="zone"
                                                    cx="50%"
                                                    cy="50%"
                                                    innerRadius="42%"
                                                    outerRadius="78%"
                                                    paddingAngle={0}
                                                    stroke="#ffffff"
                                                    strokeWidth={4}
                                                    labelLine={false}
                                                    isAnimationActive={false}
                                                    label={({
                                                        cx,
                                                        cy,
                                                        midAngle,
                                                        innerRadius,
                                                        outerRadius,
                                                        index,
                                                    }) => {
                                                        const RADIAN = Math.PI / 180;

                                                        const radius =
                                                            innerRadius +
                                                            (outerRadius - innerRadius) * 0.5;

                                                        const x =
                                                            cx +
                                                            radius *
                                                            Math.cos(-midAngle * RADIAN);

                                                        const y =
                                                            cy +
                                                            radius *
                                                            Math.sin(-midAngle * RADIAN);

                                                        const item =
                                                            distributionChartData[index];

                                                        return (
                                                            <text
                                                                x={x}
                                                                y={y}
                                                                fill="#ffffff"
                                                                textAnchor="middle"
                                                                dominantBaseline="central"
                                                                fontSize={16}
                                                                fontWeight={700}
                                                            >
                                                                {item?.percentage}
                                                            </text>
                                                        );
                                                    }}
                                                >
                                                    {distributionChartData.map(
                                                        (item, index) => (
                                                            <Cell
                                                                key={`distribution-${index}`}
                                                                fill={
                                                                    distributionColors[
                                                                    index %
                                                                    distributionColors.length
                                                                    ]
                                                                }
                                                            />
                                                        )
                                                    )}
                                                </Pie>

                                            </PieChart>
                                        </ResponsiveContainer>

                                        {/* Donut Center */}
                                        <div className="titan-donut-center">
                                            <strong>{totalOccupants}</strong>
                                            <span>Total Occupancy</span>
                                        </div>
                                    </div>
                                    {/* =================================================
                                            DONUT LEGEND
                                        ================================================= */}

                                    <div className="titan-distribution-legend">
                                        {distributionData.map((item, index) => {
                                            const percentage =
                                                item?.percentage !== undefined &&
                                                    item?.percentage !== null
                                                    ? String(item.percentage).replace("%", "")
                                                    : getPercentage(item?.value);

                                            return (
                                                <div
                                                    className="titan-distribution-item"
                                                    key={`${item?.zone}-${index}`}
                                                >
                                                    <span
                                                        className="titan-distribution-dot"
                                                        style={{
                                                            backgroundColor:
                                                                distributionColors[
                                                                index % distributionColors.length
                                                                ],
                                                        }}
                                                    />

                                                    <span className="titan-distribution-zone">
                                                        {item?.zone}
                                                    </span>

                                                    <span className="titan-distribution-percent">
                                                        ({percentage}
                                                        %)
                                                    </span>
                                                </div>
                                            );
                                        })}
                                    </div>
                                </>
                            ) : (
                                /* =================================================
                                                       DONUT NO DATA
                                                    ================================================= */

                                <NoDataAvailable message="Occupancy distribution data is not available." />
                            )}
                        </div>
                    </div>

                    {/* =================================================
                            BOTTOM SUMMARY
                        ================================================= */}

                    <section className="titan-summary">
                        {/* Total Occupants */}

                        <div className="titan-summary-item">
                            <div className="titan-summary-icon orange">
                                <UsersRound size={36} strokeWidth={1.7} />
                            </div>

                            <div className="titan-summary-content">
                                <span>Total Occupancy</span>

                                <strong>
                                    {bottomCards.totalOccupants ?? totalOccupants ?? 0}
                                </strong>
                            </div>
                        </div>

                        <div className="titan-summary-divider" />

                        {/* Gents */}

                        <div className="titan-summary-item">
                            <div className="titan-summary-icon purple">
                                <UserRound size={36} strokeWidth={1.7} />
                            </div>

                            <div className="titan-summary-content">
                                <span>Gents</span>

                                <strong>{bottomCards.gents ?? 0}</strong>
                            </div>
                        </div>

                        <div className="titan-summary-divider" />

                        {/* Ladies */}

                        <div className="titan-summary-item">
                            <div className="titan-summary-icon blue">
                                <UserRoundPlus size={36} strokeWidth={1.7} />
                            </div>

                            <div className="titan-summary-content">
                                <span>Ladies</span>

                                <strong>{bottomCards.ladies ?? 0}</strong>
                            </div>
                        </div>

                        <div className="titan-summary-divider" />

                        {/* Overall Occupancy */}

                        <div className="titan-summary-item titan-overall">
                            <div className="titan-summary-icon green">
                                <Gauge size={36} strokeWidth={1.7} />
                            </div>

                            <div className="titan-summary-content">
                                <span>Overall Occupancy</span>

                                <strong>{occupancy}%</strong>
                            </div>
                        </div>
                    </section>
                </div>

                {/* =================================================
                        RIGHT COLUMN
                    ================================================= */}

                <div className="titan-right-column">
                    {/* =================================================
                            OCCUPANCY BY LOCATION
                        ================================================= */}

                    <div className="titan-chart-card titan-location-card">
                        <div className="titan-chart-heading">
                            <div>
                                <h2>
                                    Occupancy by Zones <span>(Gents / Ladies)</span>
                                </h2>

                                <p>Occupancy count across all locations</p>
                            </div>
                        </div>

                        {/* =================================================
                                BAR DATA AVAILABLE
                            ================================================= */}

                        {occupancyByLocation.length > 0 ? (
                            <>
                                <div className="titan-location-chart">
                                    <ResponsiveContainer width="100%" height="100%">
                                        <BarChart
                                            data={occupancyByLocation}
                                            margin={{
                                                top: 28,
                                                right: 10,
                                                left: 10,
                                                bottom: 10,
                                            }}
                                            barCategoryGap="30%"
                                        >
                                            <Tooltip
                                                content={<LocationTooltip />}
                                                cursor={false}
                                                wrapperStyle={{
                                                    outline: "none",
                                                }}
                                            />

                                            {/* <CartesianGrid
                                                vertical={false}
                                                stroke="#dce5ef"
                                                strokeDasharray="0"
                                            /> */}
                                            <CartesianGrid
                                                stroke="#D9E1EC"
                                                strokeDasharray="3 3"
                                                vertical={false}
                                            />
                                            {/* <XAxis
                                                dataKey="zone"
                                                axisLine={false}
                                                tickLine={false}
                                                tick={{
                                                    fill: "#17234D",
                                                    fontSize: 13,
                                                    fontWeight: 650,
                                                }}
                                                label={{
                                                    value: "Zones",
                                                    position: "bottom",
                                                    offset: 0,
                                                    fill: "#63739B",
                                                    fontSize: 13,
                                                }}
                                            /> */}
                                            <XAxis
                                                dataKey="zone"
                                                axisLine={{
                                                    stroke: "#D9E1EC",
                                                    strokeWidth: 1,
                                                    strokeDasharray: "3 3",
                                                }}
                                                tickLine={false}
                                                tick={{
                                                    fill: "#17234D",
                                                    fontSize: 13,
                                                    fontWeight: 650,
                                                }}
                                                label={{
                                                    value: "Zones",
                                                    position: "bottom",
                                                    offset: 0,
                                                    fill: "#63739B",
                                                    fontSize: 13,
                                                }}
                                            />
                                            <YAxis
                                                domain={[0, 250]}
                                                ticks={[0, 50, 100, 150, 200, 250]}
                                                axisLine={false}
                                                tickLine={false}
                                                tick={{
                                                    fill: "#63739B",
                                                    fontSize: 11,
                                                }}
                                                label={{
                                                    value: "Occupancy",
                                                    angle: -90,
                                                    position: "insideLeft",
                                                    fill: "#63739B",
                                                    fontSize: 13,
                                                }}
                                            />
                                            {/* <YAxis
                                                domain={[0, 250]}
                                                ticks={[0, 50, 100, 150, 200, 250]}
                                                axisLine={false}
                                                tickLine={false}
                                                tick={{
                                                    fill: "#63739B",
                                                    fontSize: 11,
                                                }}
                                                label={{
                                                    value: "Occupancy",
                                                    angle: -90,
                                                    position: "insideLeft",
                                                    fill: "#63739B",
                                                    fontSize: 13,
                                                }}
                                            /> */}

                                            {/* GENTS */}

                                            <Bar dataKey="gents" stackId="occupancy" fill="#6652D9">
                                                <LabelList
                                                    dataKey="gents"
                                                    position="center"
                                                    fill="#ffffff"
                                                    fontSize={12}
                                                    fontWeight={600}
                                                />
                                            </Bar>

                                            {/* LADIES */}

                                            <Bar
                                                dataKey="ladies"
                                                stackId="occupancy"
                                                fill="#2CC398"
                                                radius={[4, 4, 0, 0]}
                                            >
                                                <LabelList
                                                    dataKey="ladies"
                                                    position="center"
                                                    fill="#ffffff"
                                                    fontSize={12}
                                                    fontWeight={600}
                                                />

                                                <LabelList
                                                    dataKey="total"
                                                    position="top"
                                                    fill="#17234D"
                                                    fontSize={13}
                                                    fontWeight={700}
                                                />
                                            </Bar>
                                        </BarChart>
                                    </ResponsiveContainer>
                                </div>

                                {/* =================================================
                                        BAR LEGEND
                                    ================================================= */}

                                <div className="titan-location-legend">
                                    <div>
                                        <span className="titan-gents-dot" />

                                        <span>Gents</span>
                                    </div>

                                    <div>
                                        <span className="titan-ladies-dot" />

                                        <span>Ladies</span>
                                    </div>
                                </div>
                            </>
                        ) : (
                            /* =================================================
                                                 BAR NO DATA
                                              ================================================= */

                            <NoDataAvailable message="Zone occupancy data is not available." />
                        )}
                    </div>
                </div>
            </section>
        </>
    );
});

/* =========================================================
   MAIN DASHBOARD
========================================================= */

const TitanDashboard = () => {
    /* =====================================================
         DASHBOARD STATE
      ===================================================== */

    const [dashboardData, setDashboardData] = useState(null);

    const [currentDateTime, setCurrentDateTime] = useState(new Date());

    const [apiError, setApiError] = useState("");

    /*
     * IMPORTANT
     *
     * Loader is ONLY for the initial API request.
     *
     * It will NOT become true during
     * the 15-second refresh.
     */

    const [isInitialLoading, setIsInitialLoading] = useState(true);

    /* =====================================================
         TITAN DASHBOARD API
         Direct API call from this JSX file
      ===================================================== */

    const getTitanDashData = async () => {
        try {
            const token = sessionStorage.getItem("token") || "";

            const response = await axios.get(
                "http://delbi2dev.deloptanalytics.com:3000/dashboard/getTtianCustomDashboardData",
                {
                    params: {
                        username: "Occupancy",
                    },
                    headers: {
                        Authorization: `Bearer ${token}`,
                    },
                }
            );

            console.log(
                "Titan Dashboard API Response:",
                response.data
            );

            return response.data;

        } catch (error) {
            console.error(
                "Titan Dashboard API Error:",
                error?.response?.data || error
            );

            throw error;
        }
    };

    /* =====================================================
         FETCH DASHBOARD DATA
      ===================================================== */

    const fetchDashboardData = useCallback(async () => {
        try {
            const result = await getTitanDashData();

            console.log("Titan Dashboard API Response:", result);

            /* =============================================
                         API SUCCESS VALIDATION
                      ============================================= */

            if (result?.success !== true) {
                throw new Error(
                    result?.message || "API returned an unsuccessful response",
                );
            }

            /* =============================================
                         UPDATE DATA
                      ============================================= */

            setDashboardData(result);

            setApiError("");
        } catch (error) {
            console.error("Titan Dashboard API error:", error);

            setApiError(error?.message || "Unable to refresh dashboard data");
        } finally {
            /*
             * IMPORTANT:
             *
             * This only turns the loader OFF.
             *
             * During the next 15-second API calls
             * the loader will remain OFF.
             */

            setIsInitialLoading(false);
        }
    }, []);

    /* =====================================================
         INITIAL LOAD + 15 SECOND SILENT REFRESH
      ===================================================== */

    useEffect(() => {
        /*
         * First API call
         */

        fetchDashboardData();

        /*
         * Silent refresh every 15 seconds
         */

        const refreshTimer = setInterval(() => {
            fetchDashboardData();
        }, 15000);

        return () => {
            clearInterval(refreshTimer);
        };
    }, [fetchDashboardData]);

    /* =====================================================
         CLOCK
      ===================================================== */

    useEffect(() => {
        const clockTimer = setInterval(() => {
            setCurrentDateTime(new Date());
        }, 1000);

        return () => {
            clearInterval(clockTimer);
        };
    }, []);

    /* =====================================================
         API DATA
      ===================================================== */

    const data = dashboardData?.data || {};

    /* =====================================================
         DATE
      ===================================================== */

    const formattedDate = new Intl.DateTimeFormat("en-IN", {
        day: "2-digit",
        month: "short",
        year: "numeric",
        timeZone: "Asia/Kolkata",
    }).format(currentDateTime);

    /* =====================================================
         TIME
      ===================================================== */

    const formattedTime = new Intl.DateTimeFormat("en-IN", {
        hour: "2-digit",
        minute: "2-digit",
        second: "2-digit",
        hour12: true,
        timeZone: "Asia/Kolkata",
    }).format(currentDateTime);

    /* =====================================================
         RENDER
      ===================================================== */

    return (
        <div className="titan-dashboard">
            {/* =================================================
                BACKGROUND
            ================================================= */}

            <div className="titan-background">
                <img src={factoryImage5} alt="" className="titan-factory-watermark" />
            </div>

            {/* =================================================
                INITIAL PAGE LOADER
            ================================================= */}

            {isInitialLoading && (
                <div className="titan-initial-loader" role="status" aria-live="polite">
                    <div className="titan-loader-spinner" />

                    <span>Loading dashboard...</span>
                </div>
            )}

            {/* =================================================
                MAIN CONTENT
            ================================================= */}

            <main className="titan-dashboard-content">
                {/* =================================================
                    HEADER
                ================================================= */}

                <header className="titan-header">
                    {/* LEFT HEADER */}

                    <div className="titan-header-left">
                        {/* BRAND LOGOS */}

                        <div className="titan-brand-logos">
                            {/* TANISHQ */}

                            <div className="titan-brand-item tanishq-brand">
                                <img
                                    src={titanLogo2}
                                    alt="Tanishq"
                                    className="titan-logo-image tanishq-logo-image"
                                    loading="eager"
                                />
                            </div>

                            {/* DIVIDER */}

                            <span className="titan-brand-divider" />

                            {/* TITAN COMPANY */}

                            <div className="titan-brand-item titan-company-brand">
                                <img
                                    src={titanLogo}
                                    alt="Titan Company"
                                    className="titan-logo-image titan-company-logo-image"
                                    loading="eager"
                                />
                            </div>
                        </div>

                        {/* TITLE */}

                        <div className="titan-title-block">
                            <h1>Factory Occupancy Overview</h1>

                            {/* Keep hidden if your existing CSS/design doesn't use subtitle */}

                            {/* 
                            <p>
                                Live occupancy status across all locations
                            </p>
                            */}
                        </div>
                    </div>

                    {/* =================================================
                        RIGHT HEADER
                    ================================================= */}

                    <div className="titan-header-right">
                        {/* LIVE */}

                        <div className="titan-live">
                            <span className="titan-live-dot" />

                            <span>LIVE</span>
                        </div>

                        {/* DIVIDER */}

                        <span className="titan-header-line" />

                        {/* DATE */}

                        <div className="titan-header-meta">
                            <CalendarDays size={15} strokeWidth={1.8} />

                            <span>{formattedDate}</span>
                        </div>

                        {/* DIVIDER */}

                        <span className="titan-header-line" />

                        {/* TIME */}

                        <div className="titan-header-meta">
                            <Clock3 size={15} strokeWidth={1.8} />

                            <span>{formattedTime}</span>
                        </div>
                    </div>
                </header>

                {/* =================================================
                    OPTIONAL API ERROR
                ================================================= */}

                {/*
                {apiError && (
                    <div
                        className="titan-api-status"
                        role="status"
                    >
                        {apiError}
                    </div>
                )}
                */}

                {/* =================================================
                    DASHBOARD DATA
                ================================================= */}

                <TitanDashboardData data={data} />

                {/* =================================================
                    FOOTER
                ================================================= */}

                <footer className="titan-footer">
                    {/* LEFT - UPDATE NOTE */}

                    <div className="titan-footer-note">
                        <span className="titan-footer-note-icon">i</span>

                        <span className="titan-footer-note-text">
                            Note : Counts are updated every 15 secs.
                        </span>
                    </div>

                    {/* RIGHT - COPYRIGHT */}

                    <div className="titan-footer-right">
                        <span className="titan-footer-copyright">
                            Copyright © {new Date().getFullYear()} All Rights Reserved
                        </span>

                        <img
                            src={footerlogo}
                            alt="Delopt"
                            className="footer_logo"
                            loading="eager"
                        />
                    </div>
                </footer>
            </main>
        </div>
    );
};

export default TitanDashboard;
